% This function is programmed by Jianan Liu at JJU 
% This is a simple demo of MSBSO
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the 
% following paper by the author of the code "Liu J, Peng H, Wu Z, et al. Multi-strategy brain storm 
% optimization algorithm with dynamic parameters adjustment[J]. Applied Intelligence, 2020, https://doi.org/10.1007/s10489-019-01600-7."..
%--------------------------------------------------------------------------------------------------------

%% The following is the main program of MSBSO.
function MSBSO_3_CEC2013
clear all
tic;
fprintf('Now is running MSBSO\n');
fun=4;    %There are 28 evaluation functions to choose from(1:28)
fhd= str2func('cec13_func');
xmin = -100;
xmax = 100;
funopt = [-1400:100:-100 100:100:1400];
global initial_flag
initial_flag = 0;
D  = 30;   %Setting individual dimensions
NP =100;   %The number of individuals in a population
F = 0.7;   %The initial value of the parameters(F&CR)
CR = 0.9;
NC=5;      %The number of clusters
nfevalmax = 300000;  %Total evaluation times
outcome = [];
lowbound  = ones(1,D).*xmin;
highbound = ones(1,D).*xmax;
pop       = zeros(NP,D);
centers =zeros(NC,D);
for i=1:NP    %Generate 100 random individuals
    pop(i,:) = lowbound + rand(1,D).*(highbound - lowbound);
end
for i=1:NP
    sorted_pop(i,:) = lowbound + rand(1,D).*(highbound - lowbound);
end
for i=1:NC    %Five cluster centers are randomly generated
    centers(i,:)=lowbound + rand(1,D).*(highbound - lowbound);
end
val       = zeros(NP,1);          %Initialize the fitness value of individuals 
sorted_val=zeros(NP,1);           %Initialize the fitness value of the sorted individuals
nfeval    = 0;                    % number of function evaluations
for i=1:NP                        % Calculate fitness values for 100 individuals 
    val(i,1)  = feval(fhd,pop(i,:)',fun);
end
nfeval  = nfeval + NP;
while nfeval <nfevalmax
    cluster = kmeans( pop, NC,'Distance','cityblock','Start',centers,'EmptyAction','singleton');
    copyvall=val;
    for i=1:10
    [~,y]=min(copyvall);
    dex(i)=y;
    copyvall(y)=inf;
    end
    [~,wInd] = max(val);  %Looking for individual with maximum fitness
    [~,gMin]=min(val);    %Looking for individual with minimum fitness
    global_best=pop(gMin,:);    %Save the best individual
    fitCB_values = repmat(val(wInd,1),NC,1);
    number_iNCluster = zeros(NC,1);   %The number of individuals contained in each cluster.
    best=zeros(NC,1);
    for idx = 1:NP
        number_iNCluster(cluster(idx,1),1)= number_iNCluster(cluster(idx,1),1) + 1;%Count the number of individuals in each cluster
        if fitCB_values(cluster(idx,1),1) > val(idx,1)   % find the best individual in each cluster
            fitCB_values(cluster(idx,1),1) = val(idx,1);
            best(cluster(idx,1),1) = idx;
        end
    end
    % form population sorted according to clusters
    counter_cluster = zeros(NC,1);
    acculate_num_cluster = zeros(NC,1);
    for idx =2:NC
        acculate_num_cluster(idx,1) = acculate_num_cluster((idx-1),1) + number_iNCluster((idx-1),1);
    end
    for idx = 1:NP
        counter_cluster(cluster(idx,1),1) = counter_cluster(cluster(idx,1),1) + 1 ;
        temIdx = acculate_num_cluster(cluster(idx,1),1) +  counter_cluster(cluster(idx,1),1);
        sorted_pop(temIdx,:) =pop(idx,:);
        sorted_val(temIdx,1) = val(idx,1);
    end
    for idx=1:NC   %If all fitness values in the cluster are the same, then the cluster center is randomly selected.
        if(best(idx)==0)
            best(idx)=acculate_num_cluster(idx,1) + ceil(rand() * number_iNCluster(idx,1));
        end
    end
     for idx = 1:NC     %Five cluster centers were determined.
            centers(idx,:) = pop(best(idx,1),:);        
     end
    for i=1:NP 
        tempx = pop(i, :);
        jrand=fix(1+D*rand);
        if(rand>exp(1-(nfevalmax/(nfevalmax-nfeval+1))))
                if(rand<0.4) %Adopt Scheme4 (MSBSO/three/rand-to-best)
                    numrand=randperm(5, 2);
                    r1=numrand(1);
                    rand1=acculate_num_cluster(r1,1) + ceil(rand() * number_iNCluster(r1,1));
                    vrand1=sorted_pop(rand1,:);
                    r2=numrand(2);
                    rand2=acculate_num_cluster(r2,1) + ceil(rand() * number_iNCluster(r2,1));
                    vrand2=sorted_pop(rand2,:);
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) = (global_best(j)+F.*(vrand1(j)-vrand2(j)));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end
                else %Adopt Scheme3 (MSBSO/one/rand-to-center) 
                    while 1
                      numrand=randperm(5, 1);
                      if(number_iNCluster(numrand,1)>2)
                      break;
                      end
                    end   
                    rands=acculate_num_cluster(numrand,1) + randperm(number_iNCluster(numrand,1),2);
                    vrand1=sorted_pop(rands(1),:);
                    vrand2=sorted_pop(rands(2),:);
                    vrand3=centers(numrand,:);
                    for j=1:D
                        if (rand<CR || j==jrand )  
                            tempx(j) = (vrand3(j)+F.*(vrand1(j)-vrand2(j)));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end   
                end
            else%Adopt Scheme1 (MSBSO/three/rand-to-center)
                if(rand<0.8)
                    numrand=randperm(5, 3);
                    r1=numrand(1);
                    rand1=acculate_num_cluster(r1,1) + ceil(rand() * number_iNCluster(r1,1));
                    vrand1=sorted_pop(rand1,:);
                    r2=numrand(2);
                    rand2=acculate_num_cluster(r2,1) + ceil(rand() * number_iNCluster(r2,1));
                    vrand2=sorted_pop(rand2,:);
                    r3=numrand(3);
                    rand3=acculate_num_cluster(r3,1) + ceil(rand() * number_iNCluster(r3,1));
                    vrand3=centers(randperm(5,1),:);
                    for j=1:D
                        if (rand<CR || j==jrand )
                              tempx(j) = (vrand3(j)+F.*(vrand1(j)-vrand2(j)));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end 
                else %Adopt Scheme2 (MSBSO/two/rand-to-best)
                      while 1
                         numrand=randperm(5, 1);
                         if(number_iNCluster(numrand,1)>2)
                             break;
                         end
                      end    
                    rands=acculate_num_cluster(numrand,1) + randperm(number_iNCluster(numrand,1),3);
                    vrand1=sorted_pop(rands(1),:);
                    vrand2=sorted_pop(rands(2),:);
                    for j=1:D
                        if (rand<CR || j==jrand ) 
                            tempx(j) =(global_best(j)+F.*(vrand1(j)-vrand2(j)));
                            if (tempx(j)<lowbound(j)|| tempx(j)>highbound(j))
                                tempx(j) = lowbound(j) + rand*(highbound(j) - lowbound(j));
                            end
                        end
                    end   
                    
                end
        end 
        tempval = feval(fhd, tempx', fun);   %Calculate the fitness value of the new individual
        nfeval  = nfeval + 1;     
        if tempval < val(i)         %Save excellent new individual.
            val(i)   = tempval;
            pop(i,:) = tempx;
        end
    end %--for i=1:NP
    GlobalMin = min(val);
    outcome   = [outcome GlobalMin];
end %--while nfeval <nfevalmax
CPUtime   = toc;
fprintf('best value=%d\n',GlobalMin-funopt(fun));
end




