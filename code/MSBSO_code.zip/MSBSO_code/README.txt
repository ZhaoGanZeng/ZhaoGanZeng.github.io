Welcome to access Hu Peng's Homepage, http://www.escience.cn/people/penghu/papersandcodes.html,
Our papers and codes are avaliable on the website. 

There are three folders in total. The file prefixed with "MSBSO”in each folder is the main file. You can test the performance of the corresponding algorithm by running the specific file prefixed with "MSBSO”.

If you find this code useful in your work, please cite the 
following paper by the author of the code "Liu J, Peng H, Wu Z, et al. Multi-strategy brain storm 
optimization algorithm with dynamic parameters adjustment[J]. Applied Intelligence, 2020, https://doi.org/10.1007/s10489-019-01600-7.".

Two issues should be noticed: first, make each folder as a workspace; second, you need to deploy "TDM-GCC-64" environment variables.