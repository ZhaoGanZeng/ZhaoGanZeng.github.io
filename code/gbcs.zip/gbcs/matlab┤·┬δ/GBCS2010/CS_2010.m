
clear;

%%%   ����������

% Number of nests (or different solutions)
n=3;

% Discovery rate of alien eggs/solutions
pa=0.25;

% Number of dimension
nd=1000; 
nfevalmax = 2;


%%%%% ����

%D = 1000; % dimensionality of benchmark functions
%NP = 100; % population size
runs = 2; % number of independent runs for each function, should be set to 25
%Max_FEs = 500; % maximal number of FEs, should be set to 3e+06
global initial_flag; % the global flag used in test suite


for func_num = 1:20
    
   % set the lower and upper bound for each function
   if (func_num == 1 | func_num == 4 | func_num == 7 | func_num == 8 | func_num == 9 | func_num == 12 | func_num == 13 | func_num == 14 | func_num == 17 | func_num == 18 | func_num == 19 | func_num == 20)
      lb = -100;
      ub = 100;
   end
   if (func_num == 2 | func_num == 5 | func_num == 10 | func_num == 15)
      lb = -5;
      ub = 5;
   end
   if (func_num == 3 | func_num == 6 | func_num == 11 | func_num == 16)
      lb = -32;
      ub = 32;
   end
   
   %% Simple bounds of the search domain
    % Lower bounds
    Lb=lb*ones(1,nd); 
    % Upper bounds
    Ub=ub*ones(1,nd);

   for run = 1:runs
       tic;
      initial_flag = 0; % should set the flag to 0 for each run, each function
      %pop = lb + (ub-lb)*rand(NP, D);
      for i=1:n,
          nest(i,:)=Lb+(Ub-Lb).*rand(size(Lb));
      end
      
      %val = benchmark_func(pop, func_num); % fitness evaluation
      %val = benchmark_func(nest, func_num); % fitness evaluation
        fitness=10^10*ones(n,1);
        [fmin,bestnest,nest,fitness]=get_best_nest(nest,nest,fitness,func_num);

       
        N_iter=0;
        outcome=[];
        %% Starting iterations
        while N_iter<nfevalmax
            N_iter = N_iter+1;
            % Generate new solutions (but keep the current best)
            new_nest=get_cuckoos(nest,bestnest,Lb,Ub);   
            [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,func_num);
     
            % Discovery and randomization
            new_nest=empty_nests(nest,Lb,Ub,pa) ;
    
            % Evaluate this set of solutions
            [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,func_num);
            % Update the counter again
            % Find the best objective so far  
            if fnew<fmin,
                fmin=fnew;
                bestnest=best;
            end
    
            outcome = [outcome fmin];
        end
    CPUtime   = toc;
    arr(func_num,run)=CPUtime;
    fmin_arr(func_num,run)=fmin;
    end %% End of iterations
     
         % demo output, you should save your results to some files
         %fprintf(1, 'func_num = %d, run = %d, FEs = %d\n', func_num, run);
         %fprintf(1, 'min(val) = %f\n\n', bestnest);
         fprintf(1, 'runtime = %f\n\n', CPUtime);
end
feval(str2func('save'), ( 'cputime' ), 'arr');
feval(str2func('save'), ( 'fmin_arr' ), 'fmin_arr');

