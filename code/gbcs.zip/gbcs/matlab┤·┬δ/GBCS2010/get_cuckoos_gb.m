%% Get cuckoos by Guassian Bare-bones
function nest=get_cuckoos_gb(nest,best,Lb,Ub)

    [n,D]=size(nest);
    
    for j=1:n
        
        tempu = ((best+nest(j,:))./2);
        tempd = abs(best-nest(j,:));      
        s = tempu+tempd.*randn(1,D);        
        
        % Apply simple bounds/limits
        nest(j,:)=simplebounds(s,Lb,Ub);
        
    end
end