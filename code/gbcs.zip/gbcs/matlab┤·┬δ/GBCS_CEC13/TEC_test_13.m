clear;

warning off all

format long;
format compact;

% set random seed
rand('state',sum(100*clock));
randn('state',sum(100*clock));

fhd     = str2func('TEC_test_function');

DEv = cell(1,20); % DE variants
DEv(1) = {'SMBSO'};
DEv(2) = {'SMBSO'};


Xmin    = [-100,-10,-100,-100,-30,-100,-1.28,-500,-5.12,-32,-600,-50,-50,-100,-100,-100,-600,-32,-50,-50,-5.12,-100];
Xmax    = -Xmin;

funopt = zeros(1,13);

funchoose = 1:20;

funnummax = 13;
runnummax = 30;     

for k = 1:1
    
    fhdDE = str2func( char( DEv(k) ) );
    
    empty_result.bestval   = [];
    empty_result.bestarray = [];
    empty_result.cputime   = [];

    result = repmat(empty_result,funnummax,runnummax);
    statistic = zeros(5,funnummax);

    bv  = zeros(1,runnummax);
    ct  = zeros(1,runnummax);

    for funnum=1:funnummax  

        fun = funchoose(funnum);

        for runnum=1:runnummax

            fprintf('function=%d runtime=%g ',fun,runnum);

            [bestval,bestarray,CPUtime] = feval(fhdDE,fhd,fun,Xmin(fun),Xmax(fun));
            result(funnum,runnum).bestval   = bestval-funopt(fun);
            result(funnum,runnum).bestarray = bestarray;   
            result(funnum,runnum).cputime   = CPUtime;   

            fprintf('bestval=%d\n',bestval-funopt(fun));

            bv(runnum) = bestval-funopt(fun);
            ct(runnum) = CPUtime;
        end

        statistic(1,funnum) = min(bv);
        statistic(2,funnum) = max(bv);
        statistic(3,funnum) = mean(bv);
        statistic(4,funnum) = std(bv,1);
        statistic(5,funnum) = mean(ct);
    end
    statistic=statistic';
    
    feval(str2func('save'), [ char(DEv(k)) 'yao13'], 'result', 'statistic');
    
end







                                                                                                                                                                                                                                                                                ;




