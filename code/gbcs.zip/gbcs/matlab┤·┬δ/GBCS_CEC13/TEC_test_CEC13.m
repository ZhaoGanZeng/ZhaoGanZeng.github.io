clear all
setenv('MW_MINGW64_LOC','C:\TDM-GCC-64')
mex cec13_func.cpp -DWINDOWS

% set random seed
rand('state',sum(100*clock));
randn('state',sum(100*clock));

global initial_flag
fhd = str2func('cec13_func');

DEv = cell(1,20); % DE variants
%DEv(1) = {'CUDE'};
%DEv(1) = {'DDICS'};
%DEv(1) = {'GBCS'};
DEv(1) = {'DE'};




Xmin = -100;
Xmax = 100;
 funopt = [-1400:100:-100 100:100:1400];
%funopt = zeros(1,28);
funchoose = 1:28;

funnummax = 28;
runnummax = 3;

for k = 1:1
    
    fhdDE = str2func( char( DEv(k) ) );
    
    empty_result.bestval   = [];
    empty_result.bestarray = [];
    empty_result.cputime   = [];

    result = repmat(empty_result,funnummax,runnummax);
    statistic = zeros(5,funnummax);

    bv  = zeros(1,runnummax);
    ct  = zeros(1,runnummax);

    for funnum=1:funnummax  

        fun = funchoose(funnum);

        for runnum=1:runnummax

            fprintf('function=%d runtime=%g ',funnum,runnum);  
            [bestval,bestarray,CPUtime] = feval(fhdDE,fhd,fun,Xmin,Xmax);
            result(funnum,runnum).bestval   = bestval-funopt(fun);
            result(funnum,runnum).bestarray = bestarray;   
            result(funnum,runnum).cputime   = CPUtime;   

            fprintf('bestval=%d\n',bestval-funopt(fun));

            bv(runnum) = bestval-funopt(fun);
            ct(runnum) = CPUtime;
        end

        %statistic(1,funnum) = min(bv);
        %statistic(2,funnum) = max(bv);
        %statistic(3,funnum) = mean(bv);
        %statistic(4,funnum) = std(bv,1);
        %statistic(5,funnum) = mean(ct);
        statistic(funnum,1) = min(bv);
        statistic(funnum,2) = max(bv);
        statistic(funnum,3) = mean(bv);
        statistic(funnum,4) = std(bv,1);
        statistic(funnum,5) = mean(ct);
    end

    
    feval(str2func('save'), [ char(DEv(k)) '_CEC13'], 'result', 'statistic');
    
end



