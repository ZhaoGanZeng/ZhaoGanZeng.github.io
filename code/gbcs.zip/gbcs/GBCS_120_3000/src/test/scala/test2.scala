package test.scala

import com.island.SparkStrategies.SiPDEPopulation

object test2 {

  def main(args: Array[String]): Unit = {
    val island =Array(1,2,3,4,5)
    //val arr = for (r <- 0 to 4) {
    var arr1 = island.map(i =>{
      var arr2 = island.map(r =>{
        val popSize: Int = 20 //每个岛中子群的数目
        val population: SiPDEPopulation = new SiPDEPopulation
        population.clear
        population.addRandomIndividuals(2, 3) //生成具体个体值,生成20个1000维个体，循环5次
        population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
        population.setKey(r) //设置岛的编号
        (r,population)
      })
      (i,arr2)
    })
    print(arr1.length)
    island.length
    /*val h = arr.map(i =>{
      val m = arr.length
    })*/
    val h:Int=9
  }
}
