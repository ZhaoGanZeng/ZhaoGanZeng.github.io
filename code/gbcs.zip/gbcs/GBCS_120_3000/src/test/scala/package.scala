package test

package object scala {
  val arr=for(r<-0 to 4) {
      var x:Int=6
    (r,x)
  }
  print(arr)

}
