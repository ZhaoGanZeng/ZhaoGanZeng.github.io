package CEC2013;

import java.io.*;
import java.util.Scanner;


public class testmain {
	public static void main(String[] args) throws Exception{

		/***
		 * parameters
		 *x 是从算法中传过来的个体
         * f 是计算得到的个体适应度值
         * n 是维度
         * m 种群大小
		 *func_num
		 *
		 *
		 */

		int i,j,k,n,m,func_num;
		double[] x;
		double[] f;
		File fpt = new File("/home/spark/CEC2013/src/CEC2013/input_data/shift_data.txt");
		
		m=2;
		n=10;
		
		testfunc tf = new testfunc();
		
		Scanner input = new Scanner(fpt);
		x = new double[n*m];
		for(i=0;i<n;i++){
			x[i]=input.nextDouble();  //
		}
		for(i=0;i<n;i++){
			System.out.println(x[i]);
		}
		input.close();
		
		for(i=1;i<m;i++){
			for(j=0;j<n;j++){
				x[i*n+j]=0.0;
				System.out.println(x[i*n+j]);
			}
		}
		
		f= new double[m];
		for(i=0;i<28;i++){
			func_num=i+1;
			for(k=0;k<1;k++){
				tf.test_func(x,f,n,m,func_num);
				for(j=0;j<m;j++){
					System.out.println("f"+func_num+"(x["+(j+1)+"])="+f[j]);
				}
			}
		}


	}
}


		