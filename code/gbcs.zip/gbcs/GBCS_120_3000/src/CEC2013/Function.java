package CEC2013;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;

public class Function implements Serializable{

        /** the serial version id */
        private static final long serialVersionUID = 1;

        /** the worst possible objective value */
        public static final double WORST = Double.POSITIVE_INFINITY;

        /** the best possible objective value */
        public static final double BEST = 0d;

        /** the dimension of the function */
        //protected static int m_dimension;

        /** the maximum value which the decision variables can take on */
        protected  static double m_max = 100d;
        /** the minimum value which the decision variables can take on */
        protected  static double m_min = -m_max;
        /**

         */

        protected static int m_dimension;

        protected static int m_popSize;

        protected static int fun_num;

        protected static double[] ind_;

        protected static double[] ind_array;

        testfunc tf = new testfunc();

    public Function(){

        }

    public Function(final int dimension, final int popSize,
                    final int f_num) {
        super();
        this.m_dimension = dimension;
        this.m_popSize = popSize;
        this.fun_num = f_num;
    }

        /**
         * Obtain the dimension of the function.
         *
         * @return the dimension of the function
         */
        public final int getDimension() {
            return this.m_dimension;
        }

        /**
         * Obtain the minimum value which the decision variables can take on
         *
         * @return the minimum value which the decision variables can take on
         */
        public final double getMin() {
            return -100d;
        }

        /**
         * Obtain the maximum value which the decision variables can take on
         *
         * @return the maximum value which the decision variables can take on
         */
        public final double getMax() {
            return 100d;
        }

        /**
         * Compute the value of the benchmark function. This function takes into
         * consideration only the first {{@link #getDimension()} elements of the
         * candidate vector.
         *
         * @param x
         *          the candidate solution vector
         * @return the value of the function
         */

        //算法中调用compute方法，ind是传过来的个体，在computer中调用test_fun，得到适应度值
        public double compute(final double[] ind) throws Exception{
            ind_array = new double[m_popSize];
            ind_ = ind;
            double fintess_ = tf.test_func(ind_,ind_array,m_dimension,m_popSize,fun_num);
            return fintess_;
        }
  /*
  public double computeRV(RealVector x) {
    //RealVector
    return 0;
  }
  */

        /**
         * Obtain the full name of the benchmark function (according to
         * &quot;Benchmark Functions for the CEC锟�010 Special Session and
         * Competition on Large-Scale Global Optimization&quot; Ke Tang, Xiaodong
         * Li, P. N. Suganthan, Zhenyu Yang, and Thomas Weise CEC'2010)
         *
         * @return the full name of the benchmark function
         */
        public String getFullName() {
            return null;
        }

        /**
         * Obtain the short name of the benchmark function (according to
         * &quot;Benchmark Functions for the CEC锟�010 Special Session and
         * Competition on Large-Scale Global Optimization&quot; Ke Tang, Xiaodong
         * Li, P. N. Suganthan, Zhenyu Yang, and Thomas Weise CEC'2010)
         *
         * @return the short name of the benchmark function
         */
        public String getShortName() {
            return this.getFullName();
        }

        /**
         * Obtain the optimum vector of the benchmark function
         *
         * @return the optimum vector of the benchmark function
         */
        public double[] getOptimum() {
            return null;
        }

        /**
         * the internal clone routine
         *
         * @return a clone of this object
         */
        final Function internalClone() {
            try {
                return ((Function) (super.clone()));
            } catch (Throwable t) {
                throw new RuntimeException(t); // will not happen since we implement
                // Cloneable
            }
        }

        /**
         * Clone this function
         *
         * @return a clone of this function
         */
        // //@Override
        public Object clone() {
            return this; // default behavior: return this
        }

        /**
         * Store the utility information
         *
         * @param f
         *          the directory
         * @throws Throwable
         *           a possible io exception
         */
        void storeUtilityInfo(final File f) throws Throwable {
            //
        }

        /**
         * Obtain the string representation of this function's name
         *
         * @return the string representation of this function's name
         */
        // //@Override
        public final String toString() {
            return this.getShortName() + ": " + this.getFullName(); //$NON-NLS-1$
        }

        public double getRandomValueInDomains(int index) {
        return getMin()+(Math.random() * ((getMax() - getMin()) + 1));}
    }

