package cer2003;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;
public class Common implements Serializable{
	private int POPSIZE=1000;// ����
	private int PARSNUM=1000;// ��Ⱥ
	private double ZOOM=0.5;// ��������
	private double CROSSOVER=0.9;// �������
	private double parmin=-100;//���ֵ
	private double parmax=100;//��Сֵ
	
	public int getPOPSIZE() {
		return POPSIZE;
	}
	public void setPOPSIZE(int pOPSIZE) {
		POPSIZE = pOPSIZE;
	}
	public int getPARSNUM() {
		return PARSNUM;
	}
	public void setPARSNUM(int pARSNUM) {
		PARSNUM = pARSNUM;
	}
	public double getZOOM() {
		return ZOOM;
	}
	public void setZOOM(double zOOM) {
		ZOOM = zOOM;
	}
	public double getCROSSOVER() {
		return CROSSOVER;
	}
	public void setCROSSOVER(double cROSSOVER) {
		CROSSOVER = cROSSOVER;
	}
	public double getParmin() {
		return parmin;
	}
	public void setParmin(double parmin) {
		this.parmin = parmin;
	}
	public double getParmax() {
		return parmax;
	}
	public void setParmax(double parmax) {
		this.parmax = parmax;
	}
	
	/**
	 * ��һ������������Ԫ��֮��
	 * @param x һ��һά����
	 * @param b �Ƿ�ȡ���ֵ
	 * @return
	 */
	public double sum(double[] x,boolean b){
		double ret=0.0;
		for(int i=0; i<x.length;i++){
			if (b) {
				x[i]=Math.abs(x[i]);
			}
			ret+=x[i];
		}
		return ret;
	}
	/**
	 * ��һ�������дӵ�һ��Ԫ�ؿ�ʼ�˵����һ��Ԫ��
	 * @param x ����
	 * @param b �Ƿ�ȡ���ֵ
	 * @return double
	 */
	public double multiply(double[] x,boolean b){
		double ret=0.0;
		for(int i=0; i<x.length;i++){
			if (b) {
				x[i]=Math.abs(x[i]);
			}
			ret *=x[i];
		}
		return ret;
	}
	/**
	 * ��һ�����ƽ��
	 * @param x1
	 
	 * @return 
	 */
	public double squares(double x1){
		double ret=0.0;
		ret=x1*x1;
		
		return ret;
	}
	/**
	 * ��һ����ľ��ֵ
	 * @param x1
	 * @return
	 */
	public double absolute(double x1){
		return Math.abs(x1);
	}
	
	public double y(double x){
		double ret=0.0;
		ret=1.0+((x+1)/4.0);
		return ret;
	}
	public double u(double x,double a,double k,int m){
		double ret=0.0;
		if (x>a) {
			ret=k*Math.pow((x-a), m);
		}
		if(x<-a){
			ret=k*Math.pow((-x-a), m);
		}
		if(x>=-a && x<=a){
			ret=0.0;
		}
		return ret;
	}
	//用下面的函数将结果写入到文件中
	public static void appendMethodB(String fileName, String content){
		try {
			//打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件
			FileWriter writer = new FileWriter(fileName, true);
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
}
