package cer2003;


public class F1 extends Function {

	private static final long serialVersionUID = 1;

	/** the maximum value */
	public static final double max = 100d;

	/** the minimum value */
	public static final double min = (-max);

	/** the lookup table */
	/** the lookup table */

	public F1(){
		
	}
	public F1(int dimension, double min, double max) {
		super(dimension, min, max);
		// TODO Auto-generated constructor stub
	}
//求平方和

	@Override
	public double compute(double[] x) {
		// TODO Auto-generated method stub
		//sphere function
		double ret=0.0;
		 for(int i=0; i<x.length;i++){			
			  ret +=common.squares(x[i]);		
		 }

		/*for (int j=0;j<10000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}
	/*
	@Override
	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for(int i=0; i<x.getDimension();i++){
			ret +=common.squares(x.getEntry(i));
		}
		return ret;
	}
	*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F1";
	}

	@Override
	public double[] getOptimum() {
		// TODO Auto-generated method stub
		return null;
	}

}
