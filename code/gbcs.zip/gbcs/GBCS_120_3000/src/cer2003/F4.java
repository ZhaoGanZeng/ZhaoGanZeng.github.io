package cer2003;

public class F4 extends Function {

	@Override
	public double compute(double[] x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length; i++) {
			if (Math.abs(x[i])>ret) {
				ret=Math.abs(x[i]);
			}
		}		
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F4";
	}
	
}
