package cer2003;

public class F7  extends Function{

	@Override
	public double compute(double[] x) {
		//Quartic with noise
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length; i++) {			
			ret +=(i+1)*common.squares(x[i]*x[i]);
		}	
		ret +=Math.random();
		/*for (int j=0;j<25000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F7";
	}
	
}
