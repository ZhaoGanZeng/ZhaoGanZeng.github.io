package cer2003;

public class F2 extends Function {

	public F2(){
		
	}
	public F2(int dimension, double min, double max) {
		super(dimension, min, max);
		// TODO Auto-generated constructor stub
	}
	@Override
	public double compute(double[] x) {
		//Schwefel 2.22
		// TODO Auto-generated method stub
		double ret=0.0;		
		ret=common.sum(x, true)+common.multiply(x, true);
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F2";
	}

	
}
