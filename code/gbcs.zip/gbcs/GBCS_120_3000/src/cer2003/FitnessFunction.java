package cer2003;


import scala.Serializable;

/**
 * Abstract class for user-defined fitness function
 * @author Dann
 */
public abstract class FitnessFunction   implements Serializable {//  implements Serializable

    /**
     * Length of genotype / number of dimensions.
     */
    protected int specimenLength;
    /**
     * Array of lower restrictions for all dimensions
     */
    protected double minRestrictions[];
    /**
     * Array of upper restrictions for all dimensions
     */
    protected double maxRestrictions[];

    /**
     * Contructor, takes length of genotype/number of dimensions and initializes restriction arrays
     * @param length Length of genotype / number of dimensions.
     */
    public FitnessFunction(int length) {
        this.specimenLength = length;
        minRestrictions = new double[length];
        maxRestrictions = new double[length];
    }

    /**
     * 
     * @param s Array of DoubleWritables representing genotype
     * @return value of fitness function for given genotype
     */
    public abstract double evaluate(Double[] s);

    //public abstract double evaluate(ArrayList<Double> s);

    /**
     * 
     * @param genotype Array of doubles representing genotype
     * @return value of fitness function for given genotype
     */
    public abstract double evaluate(double[] genotype);

    /**
     * 
     * @param i Number of requested dimension 
     * @return lower restriction for requested dimension
     */
    public double getMinRestriction(int i) {
        try {
            return minRestrictions[i];
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("!!! Restrictions index out of range");
            return 0.0;
        }
    }

    /**
     * 
     * @param i Number of requested dimension 
     * @return upper restriction for requested dimension
     */
    public double getMaxRestriction(int i) {
        try {
            return maxRestrictions[i];
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("!!! Restrictions index out of range");
            return 0.0;
        }
    }

    /**
     * 
     * @return genotype length / number of dimensions
     */
    public int getDimensions(){
        return specimenLength;
    }

    /**
     * Set minimal constraints for each dimension of specimen
     * @param m Constraints
     */
    public void setMinRestriction(double m[]) {
        minRestrictions = m.clone();
    }

    /**
     * Set maximal constraints for each dimension of specimen
     * @param m Constraints
     */
    public void setMaxRestriction(double m[]) {
        maxRestrictions = m.clone();
    }

    /**
     * 
     * @param index dimension number
     * @return random value between restrictions
     */
    public double getRandomValueInDomains(int index) {
        return minRestrictions[index] + (Math.random() * ((maxRestrictions[index] - minRestrictions[index]) + 1));
    }
}
