package cer2003;

public class F8 extends Function {

	@Override
	public double compute(double[] x) {
		//Schwefel 2.26
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length; i++) {			
			ret +=(-x[i])*Math.sin(Math.sqrt(Math.abs(x[i])));
		}
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F8";
	}
	
}
