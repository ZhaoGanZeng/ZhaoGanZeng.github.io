package cer2003;


public class F3 extends Function {

	@Override
	public double compute(double[] x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length; i++) {
			double y=0.0;
			for (int j = 0; j < i; j++) {
				y +=x[j];
			}
			ret +=y*y;
		}

		/*for (int j=0;j<15000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}
	/*
	@Override
	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for(int i=0; i<x.getDimension();i++){
			double y=0.0;
			for (int j = 0; j < i; j++) {
				y +=x.getEntry(i);
			}
			ret +=y*y;
		}
		return ret;
	}
	*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F3";
	}
 
}
