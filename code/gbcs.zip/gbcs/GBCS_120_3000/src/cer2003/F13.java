package cer2003;

public class F13 extends Function {
	@Override
	public double compute(double[] x) {
		//Penalised 1
		// TODO Auto-generated method stub
		double ret=0.0,y1=0.0,y2=0.0,y3=0.0,y4=0.0;
		y1 =common.squares(Math.sin(3*Math.PI*x[0]));
		for (int i = 0; i < x.length-1; i++) {			
			
			y2 +=common.squares(x[i]-1)*(1+common.squares(Math.sin(3*Math.PI*x[i+1])));
			
			y4 +=common.u(x[i], 5, 100, 4);			
		}
		y3= common.squares(x[x.length-1]-1)*(1+common.squares(Math.sin(2*Math.PI*x[x.length-1])));
		ret=0.1*(y1+y2+y3)+y4+common.u(x[x.length-1], 5, 100, 4);
		/*for (int j=0;j<40000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F13";
	}
}
