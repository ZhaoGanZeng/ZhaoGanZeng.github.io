package cer2003;



public class F10 extends Function {
	@Override
	public double compute(double[] x) {
		// TODO Auto-generated method stub
		//shift ackley function
		double ret=0.0,y1=0.0,y2=0.0;
		for (int i = 0; i < x.length; i++) {			
			y1 +=x[i]*x[i];
			y2 +=Math.cos(2*Math.PI*x[i]);
						
		}
		ret=-20*Math.exp(-0.2*Math.sqrt(y1/x.length))-Math.exp(y2/x.length)+20+Math.exp(1);

		/*for (int j=0;j<30000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		/*double d=0.0;
		for (int j=0;j<700;j++){
			d++;
		}

		for (int j=0;j<8000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}
	/*
	@Override
	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0,y1=0.0,y2=0.0;
		for (int i = 0; i < x.getDimension(); i++) {
			y1 +=x.getEntry(i)*x.getEntry(i);
			y2 +=Math.cos(2*Math.PI*x.getEntry(i));

		}
		ret=-20*Math.exp(-0.2*Math.sqrt(y1/x.getDimension()))-Math.exp(y2/x.getDimension())+20+Math.exp(1);
		return ret;
	}
	*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F10";
	}
}
