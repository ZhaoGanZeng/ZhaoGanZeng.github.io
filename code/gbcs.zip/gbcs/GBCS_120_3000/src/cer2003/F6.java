package cer2003;

public class F6 extends Function {

	@Override
	public double compute(double[] x) {
		//Step funcction
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length-1; i++) {			
			ret +=common.squares(Math.floor(x[i]+0.5));
		}		
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F6";
	}
	
}
