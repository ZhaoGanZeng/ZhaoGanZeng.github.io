package cer2003;


public class F9 extends Function{
	@Override
	public double compute(double[] x) {
		//Rastrigin
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.length; i++) {			
			ret +=common.squares(x[i])-10*Math.cos(2*Math.PI*x[i])+10;

		}

		/*for (int j=0;j<25000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		/*
		double d=0.0;
		for (int j=0;j<800;j++){
			d++;
		}
		*/
		return ret;
	}
	/*
	@Override
	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.getDimension(); i++) {
			ret +=common.squares(x.getEntry(i))-10*Math.cos(2*Math.PI*x.getEntry(i))+10;

		}
		return ret;
	}
	*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F9";
	}
}
