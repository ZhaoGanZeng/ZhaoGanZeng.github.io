package cer2003;

public class F12 extends Function {
	@Override
	public double compute(double[] x) {
		//Penalised 2
		// TODO Auto-generated method stub
		double ret=0.0,y1=0.0,y2=0.0,y3=0.0,y4=0.0;
		y1 =10*common.squares(Math.sin(Math.PI*common.y(x[0])));//要看原函数是x[0]还 是x[i]，
		for (int i = 0; i < x.length-1; i++) {
			
			y2 +=common.squares(common.y(x[i])-1)*(1+10*common.squares(Math.sin(Math.PI*common.y(x[i+1]))));
			//y2中x下标不能到最大下标
			
			y4 +=common.u(x[i], 10, 100, 4);			
		}

		y3= common.squares(common.y(x[x.length-1])-1);
		ret=(Math.PI/x.length)*(y1+y2+y3)+y4+common.u(x[x.length-1], 10, 100, 4);
		/*for (int j=0;j<35000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		return ret;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F12";
	}
}	
