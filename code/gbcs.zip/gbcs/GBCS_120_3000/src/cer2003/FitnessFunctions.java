package cer2003;


/**
 *
 * @author Dann
 */
public class FitnessFunctions {
    //************************************************************//
    //******CEC2003，13个测试函数
    //***********************************************************

    //CER2003,F1
    //x[-100,100],fmin=f(0,...,0)=0
    public static class CER2003_F1 extends FitnessFunction {

        public CER2003_F1(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -100;
                maxRestrictions[i] = 100;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F1 f=new F1();
            return f.compute(s1);
        }

        public double evaluate(double[] s) {
            F1 f=new F1();
            return f.compute(s);
        }
    }

    //CER2003,F2
    //x[-10,10],fmin=f(0,...,0)=0
    public static class CER2003_F2 extends FitnessFunction {

        public CER2003_F2(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -10;
                maxRestrictions[i] = 10;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F2 f=new F2();
            return f.compute(s1);
        }

        public double evaluate(double[] s) {
            F2 f=new F2();
            return f.compute(s);
        }
    }

    //CER2003,F3
    //x[-100,100] fmin=f(0,...,0)=0
    public static class CER2003_F3 extends FitnessFunction {

        public CER2003_F3(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -100;
                maxRestrictions[i] = 100;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)
                s1[i]=s[i];
            F3 f=new F3();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F3 f=new F3();
            return f.compute(s);
        }
    }

    //CER2003,F4
    //x[-100,100],fmin=f(0,...,0)=0
    public static class CER2003_F4 extends FitnessFunction {

        public CER2003_F4(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -100;
                maxRestrictions[i] = 100;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F4 f=new F4();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F4 f=new F4();
            return f.compute(s);
        }
    }


    //CER2003,F5
    //x[-30,30],fmin=f(1,...,1)=0
    public static class CER2003_F5 extends FitnessFunction {

        public CER2003_F5(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -30;
                maxRestrictions[i] = 30;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F5 f=new F5();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F5 f=new F5();
            return f.compute(s);
        }
    }

    //CER2003,F6
    //x[-100,100],fmin=f(0,...,0)=0
    public static class CER2003_F6 extends FitnessFunction {

        public CER2003_F6(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -100;
                maxRestrictions[i] = 100;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F6 f=new F6();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F6 f=new F6();
            return f.compute(s);
        }
    }


    //CER2003,F7
    //x[-1.28,1.28],fmin=f(0,...,0)=0
    public static class CER2003_F7 extends FitnessFunction {

        public CER2003_F7(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -1.28;
                maxRestrictions[i] = 1.28;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F7 f=new F7();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F7 f=new F7();
            return f.compute(s);
        }
    }

    //CER2003,F8
    //x[-500,500],fmin=f(420.9687,...,420.9687)=-12569.5
    public static class CER2003_F8 extends FitnessFunction {

        public CER2003_F8(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -500;
                maxRestrictions[i] = 500;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F8 f=new F8();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F8 f=new F8();
            return f.compute(s);
        }
    }

    //CER2003,F9
    //x[-5.12,5.12],fmin=f(0,...,0)=0
    public static class CER2003_F9 extends FitnessFunction {

        public CER2003_F9(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -5.12;
                maxRestrictions[i] = 5.12;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F9 f=new F9();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F9 f=new F9();
            return f.compute(s);
        }
    }


    //CER2003,F10
    //x[-32,32],fmin=f(0,...,0)=0
    public static class CER2003_F10 extends FitnessFunction {

        public CER2003_F10(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -32;
                maxRestrictions[i] = 32;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F10 f=new F10();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F10 f=new F10();
            return f.compute(s);
        }
    }


    //CER2003,F11
    //x[-600,600],fmin=f(0,...,0)=0
    public static class CER2003_F11 extends FitnessFunction {

        public CER2003_F11(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -600;
                maxRestrictions[i] = 600;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F11 f=new F11();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F11 f=new F11();
            return f.compute(s);
        }
    }


    //CER2003,F12
    //x[-50,50],fmin=f(1,...,1)=0
    public static class CER2003_F12 extends FitnessFunction {

        public CER2003_F12(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -50;
                maxRestrictions[i] = 50;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F12 f=new F12();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F12 f=new F12();
            return f.compute(s);
        }
    }

    //CER2003,F13
    //x[-50,50],fmin=f(1,...,1)=0
    public static class CER2003_F13 extends FitnessFunction {

        public CER2003_F13(int length) {
            super(length);

            for (int i = 0; i < specimenLength; i++) {
                minRestrictions[i] = -50;
                maxRestrictions[i] = 50;
            }
        }

        public double evaluate(Double[] s) {
            double s1[]=new double[s.length];
            for(int i=0;i<s.length;i++)s1[i]=s[i];
            F13 f=new F13();
            return f.compute(s1);
        }

        @Override
        public double evaluate(double[] s) {
            F13 f=new F13();
            return f.compute(s);
        }
    }
    
}
