package cer2003;


public class F5 extends Function {

	@Override
	public double compute(double[] x) {
		// TODO Auto-generated method stub
		//Rosenbrock function
		double ret=0.0;
		for (int i = 0; i < x.length-1; i++) {
			ret +=100*common.squares((x[i+1]-x[i]*x[i]))+common.squares(x[i]-1);
		}

		/*for (int j=0;j<20000;j++){
			Math.cos(j);
			Math.sin(j);
		}*/
		return ret;
	}
	/*@Override

	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0;
		for (int i = 0; i < x.getDimension()-1; i++) {
			ret +=100*common.squares((x.getEntry(i+1)-x.getEntry(i)*x.getEntry(i)))+common.squares(x.getEntry(i)-1);
		}
		return ret;
	}*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F5";
	}


	
}
