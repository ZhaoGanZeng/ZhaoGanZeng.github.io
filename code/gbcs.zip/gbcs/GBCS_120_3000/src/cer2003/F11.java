package cer2003;



public class F11 extends Function {
	@Override
	public double compute(double[] x) {
		//Griewank
		// TODO Auto-generated method stub
		double ret=0.0,y1=0.0,y2=1.0;
		for (int i = 0; i < x.length; i++) {			
			y1 +=x[i]*x[i];
			//if(i!=0)
				y2 *=Math.cos(x[i]/Math.sqrt(i+1));
		}

		/*for (int j=0;j<35000;j++){
			Math.cos(j);
			Math.sin(j);

		}*/
		ret=(1.0/4000)*y1-y2+1;

		return ret;
	}
	/*
	@Override
	public double computeRV(RealVector x) {
		// TODO Auto-generated method stub
		double ret=0.0,y1=0.0,y2=1.0;
		for (int i = 0; i < x.getDimension(); i++) {
			y1 +=x.getEntry(i)*x.getEntry(i);
			//if(i!=0)
			y2 *=Math.cos(x.getEntry(i)/Math.sqrt(i+1));
		}
		ret=(1.0/4000)*y1-y2+1;
		return ret;
	}
	*/

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return "F11";
	}
}
