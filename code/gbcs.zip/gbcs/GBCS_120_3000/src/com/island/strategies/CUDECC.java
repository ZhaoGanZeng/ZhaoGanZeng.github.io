package com.island.strategies;

import cec2010.Function;
import com.java.tools.RandSet;
import com.util.rnd;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CUDECC extends AlgorithmCC {
	static protected double F = 0.1;
	static protected double CR = 0.1;

	static protected double lowF = 0.5;
	static protected double uppF = 0.8;
	static protected double lowCR = 0.1;
	static protected double uppCR = 0.9;
	static protected double std = 0.1;
	static protected int sn = 6;
	protected int NP = popSize;
	protected double[][] dictsucc = new double[NP][sn];
	protected double[][] dicttota = new double[NP][sn];
	int Q=6;
	int J=6;
	int[][] temp_layout=new int[Q+1][J];
	int[][] uniform_layout=new int[Q][J];

	public CUDECC() {

	}

	public CUDECC(Function f, int D_, int popSize_) {

		dimensions = D_+1;
		//函数的维度
		//this.functiondimension=1000;
		//System.out.println("dimensions=="+dimensions);
		popSize = popSize_;
		function = f;
		population.setFunction(f);
		minPopulationSize = 5;
		lowF = 0.5;
		uppF = 0.8;
		lowCR = 0.1;
		uppCR = 0.9;
		std = 0.1;
		Q=6;
		J=6;
		NP = popSize;
		sn = 6;
		dictsucc = new double[NP][sn];
		dicttota = new double[NP][sn];
		ones(dictsucc);
		ones(dicttota);
		temp_layout=Uniform_array_generate(Q+1, J);
		//uniform_layout=;
		getSubUnifor(uniform_layout,temp_layout,Q);
	}


	public RealVector generation() throws IOException {
		// TODO Auto-generated method stub
		try {
			if (popSize < minPopulationSize) {
				throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
			}
		} catch (Exception ex) {
			Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
		}

		RealVector rand1, rand2, rand3;
		RealVector noisy;// =null; //new double[dimensions];
		RealVector trial;// =null;// new double[dimensions];

		double[] active;
		//System.out.println("popSize="+popSize);
		double trialFitness, activeFitness;
		for (int ind = 0; ind < popSize; ind++) {
			trial = new ArrayRealVector(dimensions);//new double[dimensions];
			noisy = new ArrayRealVector(dimensions);//new double[dimensions];

			// if(true) {
			// throw new IndexOutOfBoundsException("CR = " + CR + "\nF = " + F);
			// }

			active = population.get(ind).toArray();//.getGenotype();
			activeFitness = population.get(ind).getEntry(dimensions - 1);

			// Choose random individuals
			//int[] randIndex = rnd.randomArray(0, popSize-1, 3, ind);
			int[] randIndex= RandSet.randomArray1(0, popSize - 1, 3, ind);//生成3个不同的随机数
			/*System.out.println("产生的随机数为");
			for(int rid=0;rid<randIndex.length;rid++){
				System.out.print(randIndex[rid]+" ");
			}
			System.out.println("产生的随机数为");*/
			rand1 = population.get(randIndex[0]);
			rand2 = population.get(randIndex[1]);
			rand3 = population.get(randIndex[2]);

			double[] sr = division(dictsucc[ind], dicttota[ind]);

			double[] P = division(sr, sum(sr));
			int scheme = Roulette(P);
			RealVector best = null;
			double randF=0;
			switch (scheme) {
				case 1:
					F=lowF + Math.random()*std;
					CR=lowCR+Math.random()*std;
					for (int j = 0; j < dimensions; j++) {
						double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom =function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
						}
						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
				case 2:
					F=uppF + Math.random()*std;
					CR=uppCR+Math.random()*std;
					for (int j = 0; j < dimensions; j++) {
						double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom = function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
						}
						//noisy[j] = pom;
						// Create trial Individual from noisy and active
						//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];
						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
				case 3:
					F=lowF + Math.random()*std;
					CR=lowCR+Math.random()*std;
					best = population.getBestIndividual();
					for (int j = 0; j < dimensions; j++) {//rand3.getGene(j)
						
						double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + + best.getEntry(j);
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom = function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
						}
						//noisy[j] = pom;
						// Create trial Individual from noisy and active
						//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
				case 4:
					F=uppF + Math.random()*std;
					CR=uppCR+Math.random()*std;
					best = population.getBestIndividual();
					for (int j = 0; j < dimensions; j++) {//rand3.getGene(j)
						double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + + best.getEntry(j);
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom = function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
						}
						//noisy[j] = pom;
						// Create trial Individual from noisy and active
						//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
				case 5:
					F=lowF + Math.random()*std;
					CR=lowCR+Math.random()*std;
					randF=Math.random();
					for (int j = 0; j < dimensions; j++) {//rand3.getGene(j)
						double temp =population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
						double pom =temp+randF*(rand1.getEntry(j) - temp)
								+F*(rand2.getEntry(j) - rand3.getEntry(j));
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom = function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
						}
						//noisy[j] = pom;
						// Create trial Individual from noisy and active
						//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
				case 6:
					F=uppF + Math.random()*std;
					CR=uppCR+Math.random()*std;
					randF=Math.random();
					for (int j = 0; j < dimensions; j++) {//rand3.getGene(j)
						double temp =population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
						double pom =temp+randF*(rand1.getEntry(j) - temp)
								+F*(rand2.getEntry(j) - rand3.getEntry(j));
						if (pom < function.getMin()|| pom > function.getMax()) {
							pom = function.getMin()+(Math.random() * ((function.getMax() - function.getMin()) + 1));//function..getRandomValueInDomains(j);
						}
						//noisy[j] = pom;
						// Create trial Individual from noisy and active
						//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

						noisy.addToEntry(j, pom);
						// Create trial Individual from noisy and active
						trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
					}
					break;
			}
			trialFitness = function.compute(trial.toArray());
			trial.setEntry(dimensions - 1,trialFitness);
			//修改dictsucc、dicttota数组中的值
			if(trialFitness<population.get(ind).getEntry(dimensions - 1)){
				dictsucc[ind][scheme-1]=dictsucc[ind][scheme-1]+1;
			}
			dicttota[ind][scheme-1]=dicttota[ind][scheme-1]+1;
			
			
			// Replace if trial is better
			if (trialFitness < activeFitness) {
				//RealVector indiv = new RealVector(population, trial);
				//indiv.setFitness(trialFitness);
				//population.set(ind, indiv);
				population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
			}

			if (population.get(ind).getEntry(dimensions - 1) < bestFitness) {
				bestIndividual = population.get(ind);
				bestFitness = bestIndividual.getEntry(dimensions - 1);
			}
		}
		
		//Uniform local search 
		int[] bid=rnd.randomArray(0, NP-1, NP);
		double[][] U = new double[NP][dimensions];

		
		List<int[]> subvectors =Uniform_local_search(U, population.get(bid[0]).toArray(),
				population.get(bid[1]).toArray()
				, dimensions, uniform_layout, Q, J);
		double[] fit_u=new double[Q];
		for(int j=0;j<Q;j++){
			fit_u[j]=function.compute(U[j]);
		}
		double[] minfit=min(fit_u);
		if(bid[0]>minfit[0]){			
			////更改该种群中个体bid(0)
			//SiPDEIndividuals indiv = new SiPDEIndividuals(population,new ArrayRealVector(U[(int)minfit[1]]));
			RealVector indiv= new ArrayRealVector(U[(int)minfit[1]]).append(minfit[0]);
			//indiv.setFitness(minfit[0]); //适应度值

			//new ArrayRealVector(trial)
			population.set(bid[0], indiv);
		}else if(bid[1]>minfit[0]){
			////更改该种群中个体bid(1)
			RealVector indiv =  new ArrayRealVector(U[(int)minfit[1]]).append(minfit[0]);
			//indiv.setFitness(minfit[0]);
			population.set(bid[1], indiv);
		}
		//
		bestFitness=population.getBestIndividual().getEntry(dimensions - 1);
			
		return bestIndividual;
	}

	@Override
	public RealVector generation(int ind) throws IOException {
		return bestIndividual;
	}

	@Override
	public RealVector generationCC(RealVector bestind, int l, int u, int[] subscript) throws IOException {
		// TODO Auto-generated method stub
		try {
			if (popSize < minPopulationSize) {
				throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
			}
		} catch (Exception ex) {
			Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
		}

		RealVector rand1, rand2, rand3;
		RealVector noisy;// =null; //new double[dimensions];
		RealVector trial;// =null;// new double[dimensions];

		double[] active;
		//System.out.println("popSize="+popSize);
		double trialFitness, activeFitness;
		//最优值best
		double best1=bestind.getEntry(bestind.getDimension()-1);
		//临时最优个体
		RealVector IndBest=new ArrayRealVector(dimensions);

		bestIndividual=new ArrayRealVector(bestind.getDimension());
		//System.out.println("==开始l=="+l+"==u==" + u);
		for (int bi=0;bi<bestind.getDimension();bi++){
			bestIndividual.setEntry(bi,bestind.getEntry(bi));
		}
		//进化的代数
		for (int iter=0;iter<generationsPerRound;iter++) {
			for (int ind = 0; ind < popSize; ind++) {
				trial = new ArrayRealVector(dimensions);//new double[dimensions];
				noisy = new ArrayRealVector(dimensions);//new double[dimensions];
				active = population.get(ind).toArray();//.getGenotype();
				activeFitness = population.get(ind).getEntry(dimensions - 1);

				// Choose random individuals
				//int[] randIndex = rnd.randomArray(0, popSize-1, 3, ind);
				int[] randIndex = RandSet.randomArray1(0, popSize - 1, 3, ind);//生成3个不同的随机数
				rand1 = population.get(randIndex[0]);
				rand2 = population.get(randIndex[1]);
				rand3 = population.get(randIndex[2]);

				double[] sr = division(dictsucc[ind], dicttota[ind]);

				double[] P = division(sr, sum(sr));
				int scheme = Roulette(P);
				RealVector best = null;
				double randF = 0;
				switch (scheme) {
					case 1:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						for (int j = 0; j < dimensions-1; j++) {
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
							}
							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 2:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						for (int j = 0; j < dimensions-1; j++) {
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];
							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 3:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						best = bestIndividual;
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)

							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + +best.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 4:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						best = bestIndividual;
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + +best.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 5:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						randF = Math.random();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double temp = population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
							double pom = temp + randF * (rand1.getEntry(j) - temp)
									+ F * (rand2.getEntry(j) - rand3.getEntry(j));
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 6:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						randF = Math.random();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double temp = population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
							double pom = temp + randF * (rand1.getEntry(j) - temp)
									+ F * (rand2.getEntry(j) - rand3.getEntry(j));
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function..getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
				}
				//////////////////修改////////////////////////
				int index = 0;
				for (int i = l; i <= u; i++) {
					bestind.setEntry(subscript[i], trial.getEntry(index));
					index++;
				}
				trialFitness = function.compute(bestind.getSubVector(0, bestind.getDimension() - 1).toArray()); //function.evaluate(trial);
				//trialFitness = function.compute(trial.toArray());

				//修改dictsucc、dicttota数组中的值
				if (trialFitness < population.get(ind).getEntry(dimensions - 1)) {
					dictsucc[ind][scheme - 1] = dictsucc[ind][scheme - 1] + 1;
				}
				dicttota[ind][scheme - 1] = dicttota[ind][scheme - 1] + 1;


				// Replace if trial is better
				if (trialFitness < activeFitness) {
					//RealVector indiv = new RealVector(population, trial);
					//indiv.setFitness(trialFitness);
					//population.set(ind, indiv);
					trial.setEntry(dimensions - 1, trialFitness);
					population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
				}

				if (population.get(ind).getEntry(dimensions - 1) < best1) {
					//bestIndividual = population.get(ind);
					for (int popj=0;popj<population.get(ind).getDimension();popj++) {
						bestIndividual.setEntry(popj, population.get(ind).getEntry(popj));
					}
					best1 = bestIndividual.getEntry(dimensions - 1);
				}
			}


			//Uniform local search
			int[] bid = rnd.randomArray(0, NP - 1, NP);
			double[][] U = new double[NP][dimensions - 1];


			//int dimlength=bestind.getDimension()-1;
			//System.out.println("==bid[0]==="+bid[0]+"===bestind.getDimension()=="+bestind.getDimension());
			//System.out.println("D"+this.dimensions);
			//.getSubVector(0, dimlength)
			List<int[]> subvectors = Uniform_local_search(U, population.get(bid[0]).toArray(),
					population.get(bid[1]).toArray()
					, dimensions - 1, uniform_layout, Q, J);
			double[] fit_u = new double[Q];
			//System.out.println("==U=="+U[0].length);
			for (int j = 0; j < Q; j++) {
				int Uindex = 0;//
				for (int i = l; i <= u; i++) {
					bestind.setEntry(subscript[i], U[j][Uindex]);
					Uindex++;
				}
				fit_u[j] = function.compute(bestind.toArray());//U[j]
			}
			double[] minfit = min(fit_u);
			if (bid[0] > minfit[0]) {
				////更改该种群中个体bid(0)
				//SiPDEIndividuals indiv = new SiPDEIndividuals(population,new ArrayRealVector(U[(int)minfit[1]]));
				RealVector indiv = new ArrayRealVector(U[(int) minfit[1]]).append(minfit[0]);
				//indiv.setFitness(minfit[0]); //适应度值

				//new ArrayRealVector(trial)
				population.set(bid[0], indiv);
			} else if (bid[1] > minfit[0]) {
				////更改该种群中个体bid(1)
				RealVector indiv = new ArrayRealVector(U[(int) minfit[1]]).append(minfit[0]);
				//indiv.setFitness(minfit[0]);
				population.set(bid[1], indiv);
			}
			//
			//bestIndividual= population.getBestIndividual();
			bestFitness = population.getBestIndividual().getEntry(dimensions - 1);
		}

		return bestIndividual;
	}

	public RealVector generationCC(RealVector bestind,   List<Integer> subscript) throws IOException {
		// TODO Auto-generated method stub
		try {
			if (popSize < minPopulationSize) {
				throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
			}
		} catch (Exception ex) {
			Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
		}

		RealVector rand1, rand2, rand3;
		RealVector noisy;// =null; //new double[dimensions];
		RealVector trial;// =null;// new double[dimensions];

		double[] active;

		bestIndividual=new ArrayRealVector(bestind.getDimension());
		//System.out.println("==开始l=="+l+"==u==" + u);
		for (int bi=0;bi<bestind.getDimension();bi++){
			bestIndividual.setEntry(bi,bestind.getEntry(bi));
		}
		//int dimensions=1000;
		double trialFitness, activeFitness;
		//进化的代数
		for (int iter=0;iter<generationsPerRound;iter++) {
			//System.out.println("iter"+iter+"bestind.getDimension()="+bestind.getDimension()+"=dimensions="+dimensions);
			for (int ind = 0; ind < popSize; ind++) {
				trial = new ArrayRealVector(dimensions);//new double[dimensions];
				noisy = new ArrayRealVector(dimensions);//new double[dimensions];
				active = population.get(ind).toArray();//.getGenotype();
				activeFitness = population.get(ind).getEntry(dimensions - 1);

				// Choose random individuals
				//int[] randIndex = rnd.randomArray(0, popSize-1, 3, ind);
				int[] randIndex = RandSet.randomArray1(0, popSize - 1, 3, ind);//生成3个不同的随机数
				rand1 = population.get(randIndex[0]);
				rand2 = population.get(randIndex[1]);
				rand3 = population.get(randIndex[2]);

				double[] sr = division(dictsucc[ind], dicttota[ind]);

				double[] P = division(sr, sum(sr));
				int scheme = Roulette(P);
				RealVector best = null;
				double randF = 0;
				switch (scheme) {
					case 1:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						for (int j = 0; j < dimensions-1; j++) {
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
							}
							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 2:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						for (int j = 0; j < dimensions-1; j++) {
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];
							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 3:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						best = bestIndividual;//population.getBestIndividual();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)

							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + +best.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 4:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						best =bestIndividual; //population.getBestIndividual();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + +best.getEntry(j);
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 5:
						F = lowF + Math.random() * std;
						CR = lowCR + Math.random() * std;
						randF = Math.random();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double temp = population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
							double pom = temp + randF * (rand1.getEntry(j) - temp)
									+ F * (rand2.getEntry(j) - rand3.getEntry(j));
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function.getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
					case 6:
						F = uppF + Math.random() * std;
						CR = uppCR + Math.random() * std;
						randF = Math.random();
						for (int j = 0; j < dimensions-1; j++) {//rand3.getGene(j)
							double temp = population.get(ind).getEntry(j); //(rand1.getGene(j) - rand2.getGene(j)) * F + + best.getGene(j);
							double pom = temp + randF * (rand1.getEntry(j) - temp)
									+ F * (rand2.getEntry(j) - rand3.getEntry(j));
							if (pom < function.getMin() || pom > function.getMax()) {
								pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1));//function..getRandomValueInDomains(j);
							}
							//noisy[j] = pom;
							// Create trial Individual from noisy and active
							//trial[j] = (Math.random() < CR) ? noisy[j] : active[j];

							noisy.addToEntry(j, pom);
							// Create trial Individual from noisy and active
							trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
						}
						break;
				}
				//////////////////修改////////////////////////
				int index = 0;
				//int l=subscript[0];
				/*System.out.println("=ind="+ind+"=subscript.size="+subscript.size()+"=="+bestIndividual.getDimension());
				for(int j=0;j<bestIndividual.getDimension();j++){
					System.out.print(bestIndividual.getEntry(j)+";");
				}*/
				for (int i = 0; i < subscript.size(); i++) {
					System.out.println("i="+subscript.get(i));
					bestIndividual.setEntry(subscript.get(i), trial.getEntry(index));
					index++;
				}

				trialFitness = function.compute(bestind.getSubVector(0, bestind.getDimension() - 1).toArray()); //function.evaluate(trial);
				//trialFitness = function.compute(trial.toArray());

				//修改dictsucc、dicttota数组中的值
				if (trialFitness < population.get(ind).getEntry(dimensions - 1)) {
					dictsucc[ind][scheme - 1] = dictsucc[ind][scheme - 1] + 1;
				}
				dicttota[ind][scheme - 1] = dicttota[ind][scheme - 1] + 1;


				// Replace if trial is better
				if (trialFitness < activeFitness) {
					//RealVector indiv = new RealVector(population, trial);
					//indiv.setFitness(trialFitness);
					//population.set(ind, indiv);
					trial.setEntry(dimensions - 1, trialFitness);
					population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
				}

				if (population.get(ind).getEntry(dimensions - 1) < bestFitness) {
					//bestIndividual = population.get(ind);
					//System.out.println("population.get(ind).getDimension()="+population.get(ind).getDimension());
					for (int popj=0;popj<population.get(ind).getDimension();popj++) {
						bestIndividual.setEntry(popj, population.get(ind).getEntry(popj));
					}
					bestFitness = bestIndividual.getEntry(dimensions - 1);
				}
			}

			//Uniform local search
			int[] bid = rnd.randomArray(0, NP - 1, NP);
			double[][] U = new double[NP][dimensions - 1];


			//int dimlength=bestind.getDimension()-1;
			//System.out.println("==bid[0]==="+bid[0]+"===bestind.getDimension()=="+bestind.getDimension());
			//System.out.println("D"+this.dimensions);
			//.getSubVector(0, dimlength)
			List<int[]> subvectors = Uniform_local_search(U, population.get(bid[0]).toArray(),
					population.get(bid[1]).toArray()
					, dimensions - 1, uniform_layout, Q, J);
			double[] fit_u = new double[Q];
			//System.out.println("==U=="+U[0].length);
			for (int j = 0; j < Q; j++) {
				int Uindex = 0;//
				//System.out.println("==trial=="+subscript.size()+"==U["+j+"]=="+U[j].length);
				for (int i = 0; i < subscript.size(); i++) {
					bestind.setEntry(subscript.get(i), U[j][Uindex]);
					Uindex++;
				}
				fit_u[j] = function.compute(bestind.toArray());//U[j]
			}
			double[] minfit = min(fit_u);
			if (bid[0] > minfit[0]) {
				////更改该种群中个体bid(0)
				//SiPDEIndividuals indiv = new SiPDEIndividuals(population,new ArrayRealVector(U[(int)minfit[1]]));
				RealVector indiv = new ArrayRealVector(U[(int) minfit[1]]).append(minfit[0]);
				//indiv.setFitness(minfit[0]); //适应度值

				//new ArrayRealVector(trial)
				population.set(bid[0], indiv);
			} else if (bid[1] > minfit[0]) {
				////更改该种群中个体bid(1)
				RealVector indiv = new ArrayRealVector(U[(int) minfit[1]]).append(minfit[0]);
				//indiv.setFitness(minfit[0]);
				population.set(bid[1], indiv);
			}
			//
			//bestFitness = population.getBestIndividual().getEntry(dimensions - 1);
			//bestIndividual=population.getBestIndividual();

			bestFitness = population.getBestIndividual().getEntry(dimensions - 1);
		}

		return bestIndividual;
	}


	@Override
	public populationCC getPopulation() {
		// TODO Auto-generated method stub
		return population;
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setParameter(String configName, float value) {

	}

	public void setParameter(String configName, double value) {
		// TODO Auto-generated method stub
		if (configName.equals("F")) {
			F = value;
		} else if (configName.equals("CR")) {
			CR = value;
		}
	}

	/**
	 * @param sr
	 * @return 求一个数组之和
	 */
	public double sum(double[] sr) {
		double value = 0;
		for (int i = 0; i < sr.length; i++) {
			value += sr[i];
		}
		return value;
	}

	/**
	 * @param sr
	 * @return 求一个数组的最小值，返回一个数组[最小值，小标]
	 */
	public double[] min(double[] sr) {
		double[] value = new double[2];
		double min=sr[0];
		int k=0;
		for (int i = 1; i < sr.length; i++) {
			//value += sr[i];
			if(sr[i]<min){   // 判断最小值
				min=sr[i];
				k=i;
			}
		}
		value[0]=min;
		value[1]=k;
		return value;
	}

	/**
	 * @param mol
	 * @param Den
	 * @return 两个数组对应值相除
	 */
	public double[] division(double[] mol, double[] Den) {
		double[] value = new double[mol.length];
		for (int i = 0; i < mol.length; i++) {
			value[i] = mol[i] / Den[i];
		}
		return value;
	}

	/**
	 * @param mol
	 * @param Den
	 * @return 两个数组对应值相除
	 */
	public double[] division(double[] mol, double Den) {
		double[] value = new double[mol.length];
		for (int i = 0; i < mol.length; i++) {
			value[i] = mol[i] / Den;
		}
		return value;
	}

	/**
	 * @param U
	 *            二维数组，指针传递；返回的值
	 * @param V
	 *            一维数组
	 * @param X
	 *            一维数组
	 * @param D
	 *            int
	 * @param uni_array
	 *            二维数组
	 * @param Q
	 *            int
	 * @param J
	 *            int
	 * @return Uniform_local_search List<int[]>
	 */
	public List<int[]> Uniform_local_search(double[][] U, double[] V, double[] X, int D, int[][] uni_array, int Q,
											int J) {
		int[] nouse = new int[D];
		List<int[]> mouse = new ArrayList<int[]>();
		double[][] beta = new double[D][Q];
		zeros(beta);
		zeros(U);

		for (int i = 0; i < D; i++) {
			if (V[i] == X[i]) {
				// 将beta中的第i行赋值为
				ones(beta, i, V[i], false);
			} else {
				double inter = (X[i] - V[i]) / (Q - 1);
				beta[i][0] = V[i];
				beta[i][Q - 1] = X[i];
				for (int k = 1; k < Q - 1; k++) {
					beta[i][k] = beta[i][k - 1] + inter;
				}
			}
		}
		if (D < J) {
			for (int i = 0; i < D; i++) {
				double[] temp = new double[Q];
				temp = beta[i];
				setDoubArray(U, temp, uni_array, i, i);
				mouse.add(i, new int[] { i });
			}
		} else {
			// Divide the variables into J subvectors
			nouse = rnd.randomArray(1, D - 2, D - 2);
			nouse = subArray(nouse, 0, J);
			Arrays.sort(nouse);
			mouse.add(0, getArray(1, nouse[0]));
			for (int i = 1; i < J - 1; i++) {
				mouse.add(i, getArray(nouse[i - 1] + 1, nouse[i]));
			}
			mouse.add(J - 1, getArray(nouse[J - 2] + 1, D));
			// Implement ULS

			for (int i = 0; i < J; i++) {
				double[][] temp = getSubArray(beta, mouse.get(i));
				int k = 0;
				for (int j = 0; j < mouse.get(i).length; j++) {
					double[] temp_1 = temp[j];
					// 将U的第K列全部赋值为temp_1
					setDoubArray(U, temp_1, uni_array, i, k);
					k = k + 1;
				}
			}
		}

		return mouse;
	}

	public void setDoubArray(double[][] U, double[] temp, int[][] uni_array, int i, int k) {
		int[] temp1 = new int[uni_array.length];
		// 获取uni_array数组中的第i
		for (int j = 0; j < uni_array.length; j++) {
			temp1[j] = uni_array[j][i];
		}
		double[] temp2 = new double[uni_array.length];
		for (int j = 0; j < temp.length; j++) {
			temp2[j] = temp[temp1[j] - 1];
		}
		for (int j = 0; j < temp2.length; j++) {
			U[j][k] = temp2[j];
		}
	}

	/**
	 * @param beta
	 * @param mouse
	 * @return 从beta数组中选取mouse数组中对应的行
	 */
	public double[][] getSubArray(double[][] beta, int[] mouse) {
		double[][] value = new double[mouse.length][];
		for (int i = 0; i < value.length; i++) {
			value[i] = beta[mouse[i] - 1];
		}
		return value;
	}

	/**
	 * @param i
	 *            开始的值
	 * @param j
	 *            结束的值
	 * @return 返回一个数组 其值为i到j
	 */
	public int[] getArray(int i, int j) {
		int[] value = new int[j - i + 1];
		int line = 0;
		for (int k = i; k < j + 1; k++) {
			value[line] = k;
			line++;
		}
		return value;
	}

	/**
	 * @param value
	 * @param uniform
	 * @param Q 行数 将uniform二维数组中的第Q行去掉
	 */
	public void getSubUnifor(int[][] value, int[][] uniform, int Q) {
		for (int i = 0; i < uniform.length; i++) {
			if (i != Q) {
				for (int j = 0; j < uniform[i].length; j++) {
					value[i][j] = uniform[i][j];
				}
			}
		}
	}

	/**
	 * @param Q
	 *            行的数目
	 * @param J
	 *            列的数目
	 * @return 二维数组
	 */
	public int[][] Uniform_array_generate(int Q, int J) {
		int[][] uni_array = new int[Q][J];
		for (int i = 0; i < Q; i++) {
			uni_array[i][0] = i + 1;
		}
		int i = 2;
		for (int j = 1; j < J; j++) {
			if (gcd(Q, i) != 1) {
				i = i + 1;
			}
			uni_array[0][j] = i;
			i = i + 1;
		}
		for (i = 2; i < Q + 1; i++) {
			for (int j = 2; j < J + 1; j++) {
				if ((i * uni_array[0][j - 1]) % Q == 0) {
					uni_array[i - 1][j - 1] = Q;
				} else {
					uni_array[i - 1][j - 1] = (i * uni_array[0][j - 1]) % Q;
				}
			}
		}

		return uni_array;
	}

	/**
	 * 按轮盘赌策略选择
	 *
	 * @param P
	 *            整数数组
	 * @return 整数1->P.length
	 */
	public int Roulette(double[] P) {
		int Select = 0;
		int m = P.length;
		double r = Math.random();
		double sumP = 0;
		int j = (int) Math.ceil(m * Math.random());
		while (sumP < r) {
			sumP = sumP + P[((j - 1) % m)];
			j = j + 1;
		}
		Select = ((j - 2) % m) + 1;
		return Select;
	}

	/**
	 * @param x
	 * @param y
	 * @return 两个数的公约数
	 */
	public int gcd(int x, int y) {
		if (x == 0)
			return y;
		if (y == 0)
			return x;
		if (x > y)
			return gcd(x % y, y);
		else
			return gcd(x, y % x);
	}

	public void zeros(double[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j] = 0;
			}
		}
	}

	/**
	 * @param array
	 *            数组
	 * @param i
	 *            第几行
	 * @param V
	 *            所赋值
	 * @param t
	 *            布尔类型 false：为行或 ture：为列
	 */
	public void ones(double[][] array, int i, double V, boolean t) {
		for (int j = 0; j < array[i].length; j++) {
			if (t) {
				array[j][i] = V * 1;
			} else {
				array[i][j] = V * 1;
			}
		}
	}

	public void ones(double[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j] = 1;
			}
		}
	}

	public int[] subArray(int[] array, int i, int j) {
		int[] value = new int[j - i];
		for (int k = i; k < j; k++) {
			value[k - i] = array[k];
		}
		return value;
	}

	// 排序
	public void sort(int[] array) {

	}

	public static void main(String[] args) {
		CUDECC cude = new CUDECC();
		int[][] a = cude.Uniform_array_generate(7, 6);
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		double[] p = new double[] { 0.1667, 0.1667, 0.1667, 0.1667, 0.1667, 0.1667 };
		System.out.println("选择的策略：" + cude.Roulette(p));
		int D = 8, Q = 8;
		double[][] beta = new double[D][Q];

		cude.zeros(beta);
		// beta[0][1]=12;
		System.out.println("beta数组中的值");
		cude.ones(beta, 3, 12.89, false);
		for (int i = 0; i < beta.length; i++) {
			for (int j = 0; j < beta[i].length; j++) {
				System.out.print(beta[i][j] + " ");
			}
			System.out.println();
		}

		int[] nouse = rnd.randomArray(1, 28, 28);
		nouse = cude.subArray(nouse, 0, 5);
		Arrays.sort(nouse);
		System.out.println("submouse");
		for (int i = 0; i < nouse.length; i++) {
			System.out.print(nouse[i] + " ");
		}

		List<int[]> mouse = new ArrayList<int[]>();
		mouse.add(0, nouse);

		nouse = rnd.randomArray(1, 28, 28);
		mouse.add(1, nouse);
		// mouse.set(0, nouse);
		System.out.println();
		System.out.println("mouse");
		mouse.add(2, cude.getArray(1, 3));
		for (int i = 0; i < mouse.size(); i++) {
			for (int j = 0; j < mouse.get(i).length; j++) {
				System.out.print(mouse.get(i)[j] + " ");
			}
			System.out.println();
		}
		System.out.println("gets==");
		double[][] gets = cude.getSubArray(beta, mouse.get(2));
		for (int i = 0; i < gets.length; i++) {
			for (int j = 0; j < gets[i].length; j++) {
				System.out.print(gets[i][j] + " ");
			}
			System.out.println();
		}

		double[] p1 = new double[] { -57.6418, -17.4733, 40.3458, 18.7592, -46.5317, 75.4584, -60.7303, 67.3629,
				57.6374, -34.0488, 55.1255, 71.1837, -52.3767, -72.6397, -50.4387, -19.3264, 74.1219, 30.5952, 49.8965,
				12.9831, 8.4738, 64.5336, 6.9974, 42.1155, 7.2500, -13.9164, 55.0178, -10.6518, -85.2707, -54.1099 };
		double[] p2 = new double[] { 96.4759, -14.6185, 6.8834, -13.1619, -44.4669, -62.7334, -28.3251, -30.1763,
				-25.2333, -81.4151, 88.7603, -19.3574, 84.4435, -27.9454, -30.7375, 32.1810, -6.1797, -9.3801, 43.6382,
				-42.9662, 30.8469, -32.7055, -88.3047, 8.9477, -27.9816, -97.5296, -23.4201, -43.9870, 49.1030,
				31.6037 };
		D = 30;
		Q = 6;
		/*a = new int[][] { { 1, 2, 3, 4, 5, 6 }, { 2, 4, 6, 1, 3, 5 }, { 3, 6, 2, 5, 1, 4 }, { 4, 1, 5, 2, 6, 3 },
				{ 5, 3, 1, 6, 4, 2 }, { 6, 5, 4, 3, 2, 1 } };*/
		int[][] b =new int[6][6];
		cude.getSubUnifor(b,a,Q);

		System.out.println("输出b的值为");
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				System.out.print(b[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("输出b的值为");

		double[][] U = new double[Q][D];
		List<int[]> mou = cude.Uniform_local_search(U, p1, p2, D, b, Q, 6);
		System.out.println("输出U的值为");
		for (int i = 0; i < U.length; i++) {
			for (int j = 0; j < U[i].length; j++) {
				System.out.print(U[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("输出U的值为");
		System.out.print("输出mou的值为");
		for (int i = 0; i < mou.size(); i++) {
			System.out.println("i=" + i);
			for (int j = 0; j < mou.get(i).length; j++) {
				System.out.print(mou.get(i)[j] + " ");
			}
			System.out.println();
		}

	}

}
