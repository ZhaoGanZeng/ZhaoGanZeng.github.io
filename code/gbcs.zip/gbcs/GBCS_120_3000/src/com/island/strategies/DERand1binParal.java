package com.island.strategies;

import cer2003.FitnessFunction;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * Created by hadoop on 15-7-22.
 */
public class DERand1binParal  extends Algorithm {
    //settings
    static protected double F = 0.5;   //F – mutacní konstanta [0, 2]  0.5
    //不断变异
    static protected double CR = 0.9;  //CR – práh krizení [0, 1]

    //种群的个体
    protected int ind = 0;  //ind – 种群的个体
    //越限
    //F，CR的值会传进来了，覆盖其数值

//    static public Population population = new Population();

    public DERand1binParal(FitnessFunction f, int D_, int popSize_) {
        dimensions = D_+1;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 2;
    }
    //no
    public RealVector generation(){
        return bestIndividual;
    }

    //协同下的进化,RealVector trialFit
    public  RealVector generationCC(RealVector bestind,int l,int u,int[] subscript){
        return bestind;
    }

    public RealVector generation(int ind) {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }
        RealVector rand1, rand2, rand3;
        double[] noisy = new double[dimensions];
        double[] trial = new double[dimensions];
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double trialFitness, activeFitness;
        //System.out.println("==ind=="+ind+"===");
        //进化的代数  每一个个体进化一代返回
        //for (int iter=0;iter<generationsPerRound;iter++)
        {
            //ind为个体的数量
            //for (int ind = 0; ind < popSize; ind++)
            {
                trial = new double[dimensions];
                noisy = new double[dimensions];
                //获取第ind个个体；最后一个是适应度的值

                active = population.get(ind).toArray();
                activeFitness = population.get(ind).getEntry(dimensions - 1);
                //  Choose random
                do {
                    rand1Index = (int) (Math.random() * popSize);
                    rand1 = population.get(rand1Index);
                } while (rand1Index == ind);

                do {
                    rand2Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand2Index == rand1Index);
                rand2 = population.get(rand2Index);

                do {
                    rand3Index = (int) (Math.random() * popSize);
                } while (rand1Index == ind || rand3Index == rand1Index || rand3Index == rand2Index);
                rand3 = population.get(rand3Index);

                for (int j = 0; j < dimensions - 1; j++) {
                    double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                    //System.out.println("function.getMinRestriction(" + j + ")=" + function.getMinRestriction(j));
                    if (pom < function.getMinRestriction(j) || pom > function.getMaxRestriction(j)) {
                        pom = function.getRandomValueInDomains(j);
                    }
                    noisy[j] = pom;
                    trial[j] = (Math.random() < CR) ? noisy[j] : active[j];
                }

                trialFitness = function.evaluate(trial);
                //将适应度值放在最后一列
                trial[dimensions - 1] = trialFitness;

                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                }

                if (population.get(ind).getEntry(dimensions - 1) < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getEntry(dimensions - 1);
                }
            }
            //ind为个体的数量

            //System.out.println("第"+iter+"轮");
            //for (int ind = 0; ind < popSize; ind++) {
                for (int col=0;col<dimensions;col++) {
                    System.out.println("第" + ind + "个个体：第" + col+"列的值==" + population.getPop().getEntry(ind, col) + "  ");
                }
                System.out.println();
            //}
            //System.out.println("最优个体的适应度值" + bestFitness);
        }

        return bestIndividual;
    }

    public populationRM getPopulation() {
        return population;
    }

    public void newRound() {
        System.out.println("newRound");
    }

    public void setParameter(String configName, float value) {
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
