package com.island.strategies;

import java.io.IOException;


/**
 * Individual used to populate Population
 * @author Dann
 */
public class Individual{

    protected double[] genotype;
    protected double fitness = Double.POSITIVE_INFINITY;
    protected boolean evaluated = false;
    protected static JADEPopulation population;
    protected int index = Integer.MAX_VALUE;
    protected int dimensions;

    /**
     * 
     * @param pop Population in which Individual will be inserted into
     * @param d Number of dimensions
     */
    public Individual(JADEPopulation pop, int d) {
        double min = 0, max = 0;
        dimensions = d;
        genotype = new double[dimensions];
        population = pop;
        evaluated = false;
    }

    /**
     * 
     * @param pop Population in which Individual will be inserted into
     * @param vals Array of values used as genes
     */
    public Individual(JADEPopulation pop, double[] vals) {
        population = pop;
        genotype = vals;
        dimensions = vals.length;

        evaluated = false;
    }

    /**
     * 
     * @param pop Population in which Individual will be inserted into
     * @throws IOException
     */
    public Individual(JADEPopulation pop) throws IOException {
        population = pop;
    }


    /**
     * Sets genes to random values within restrictions
     */
    public void randomize() {
        double min, max;
        for (int i = 0; i < dimensions; i++) {
            min = population.getMinRestriction(i);
            max = population.getMaxRestriction(i);
            //  Get random double within range.
            genotype[i] = min + (Math.random() * ((max - min) + 1));
        }

        evaluated = false;
    }

    /**
     * 
     * @return genotype array
     */
    public double[] getGenotype() {
        return genotype;
    }

    /**
     * 
     * @param i index of requested gene
     * @return gene with given index
     */
    public double getGene(int i) {
        return genotype[i];
    }

    /**
     * Sets one gene to defined value val
     * @param ind Index of gene to set
     * @param val Value to set to the gene
     */
    public void setGene(int ind, double val) {
        genotype[ind] = val;
        evaluated = false;
    }

    /**
     * Sets Individuals fitness to given value f
     * @param f Value to set
     */
    public void setFitness(double f) {
        fitness = f;
        evaluated = true;
    }

    /**
     * 
     * @return fitness of Individual
     */
    public double getFitness() {
        return fitness;
    }

    /**
     * 
     * @return population index 
     */
    public int getIndex() {
        return index;
    }

    /**
     * Sets population index to value i
     * @param i Index to set
     */
    public void setIndex(int i) {
        index = i;
    }

    @Override
    public String toString() {
        String str = "";

        str += fitness + "\t";

        for (int i = 0; i < dimensions; i++) {
            str += String.format("%.6f", genotype[i]);
            if (i != dimensions - 1) {
                str += '\t';
            }
        }

        return str;
    }

    /**
     * Sets whole genotype
     * @param values
     */
    public void setValues(double[] values) {
        genotype = values;
        evaluated = false;
    }
    
    /**
     * Sets value of one gene
     * @param i Index of gene to set
     * @param value Value to set
     */
    public void setValue(int i, double value) {
        genotype[i] =  value;
        evaluated = false;
    }

    /**
     * Sets population pointer to pop
     * @param pop Population to set
     */
    public void setPopulation(JADEPopulation pop) {
        population = pop;
    }


    public int compareTo(Individual o) {
        double cost1 = fitness;
        double cost2 = o.getFitness();

        return (cost1 < cost2 ? -1 : (cost1 == cost2 ? 0 : 1));
    }

}
