package com.island.strategies;

import cec2010.Function;

import com.java.tools.RandSet;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mouse
 */
public class JADECC extends DERand1binCC {

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;
    double SF, SF2; //sucet a mocnina uspesnych F hodnot
    double SCR, nSCR; //sucet a pocet uspesnych CR hodnot
    Random rng;
    /*public JADECC(){
        super();
    }*/
    public JADECC(Function f, int D_, int popSize_) {
        super(f, D_+1, popSize_);

        minPopulationSize = 4;

        uCR = 0.5; SCR = 0; nSCR = 0;
        uF = 0.6; SF = 0; SF2 = 0;
        c = 0.1;
        p = 0.2; //20%
        numP = (int)Math.round(((double)popSize) * p);

        rng = new Random( System.currentTimeMillis());
    }

    //DE/current-to-p-best
    @Override
    public RealVector generation() {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        population.computeFandCR(popSize);
        SCR = 0; nSCR = 0;
        SF = 0; SF2 = 0;

        RealVector rand1, rand2, bi;

        RealVector noisy;
        RealVector trial;
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int biIndex = 0;
        double trialFitness, activeFitness;

        for (int ind = 0; ind < popSize; ind++) {
            trial =new ArrayRealVector(dimensions); //new double[dimensions];
            noisy = new ArrayRealVector(dimensions);//new double[dimensions];


            active = population.get(ind).toArray();
            activeFitness = population.get(ind).getEntry(population.getDimensions()-1);
            F = population.getF(ind);
            CR = population.getCR(ind);

            do {
                biIndex = rng.nextInt(numP);
                biIndex = population.getIndexFromFitnessOrder(biIndex);
            } while(biIndex == ind);
            bi = population.get(biIndex);


            int[] randindex= RandSet.randomArray1(0, popSize - 1, 3, ind,biIndex);//生成3个不同的随机数


            /*do {
                rand1Index = (rng.nextInt(popSize));
            } while(rand1Index == biIndex || rand1Index == ind);*/
            rand1 = population.get(randindex[0]);

            /*do {
                rand2Index = (rng.nextInt(popSize));
            } while(rand2Index == ind || rand2Index == biIndex || rand2Index == rand1Index);*/
            rand2 = population.get(randindex[1]);

            int rand3Index = 0;
            RealVector rand3;
            /*do {
                rand3Index = (int) (Math.random() * popSize);
            } while(rand3Index == rand1Index || rand3Index == rand2Index || rand3Index == ind);*/
            rand3 = population.get(randindex[2]);

            for (int j = 0; j < dimensions; j++) {
                double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                //double pom = active[j] + F*(bi.getGene(j) - active[j]) + F * (rand1.getGene(j) - rand2.getGene(j));

                if (pom < function.getMin() || pom > function.getMax()) {
                    pom = function.getRandomValueInDomains(j);
                }

                noisy.addToEntry(j,pom);
                double tr = (Math.random() < CR) ? noisy.getEntry(j) : active[j];
                trial.addToEntry(j,tr);
            }

            trialFitness = function.compute(trial.toArray());
            trial.addToEntry(dimensions - 1, trialFitness);
            // Replace if trial is better
            if (trialFitness < activeFitness) {
                //RealVector indiv = new ArrayRealVector(trial);
                //indiv.setFitness(trialFitness);
                population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                //population.set(ind, indiv);
                SCR += CR;
                nSCR++;
                SF += F;
                SF2 += F * F;
            }
            if(population.get(ind).getEntry(population.getDimensions() - 1) < bestFitness) {
                bestIndividual = population.get(ind);
                bestFitness = bestIndividual.getEntry(dimensions - 1);
            }
        }
        population.updateuCR(SCR, nSCR);
        population.updateuF(SF, SF2);
        return bestIndividual;
    }

    public  RealVector generationCC(RealVector bestind,int l,int u,int[] subscript){
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        population.computeFandCR(popSize);
        SCR = 0; nSCR = 0;
        SF = 0; SF2 = 0;

        RealVector rand1, rand2, bi;

        RealVector noisy;
        RealVector trial;
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int biIndex = 0;
        double trialFitness, activeFitness;
//最优值best
        double best=bestind.getEntry(bestind.getDimension()-1);
        //临时最优个体
        RealVector IndBest=new ArrayRealVector(dimensions);

        bestIndividual=new ArrayRealVector(bestind.getDimension());
        //System.out.println("==开始l=="+l+"==u==" + u);
        for (int bi1=0;bi1<bestind.getDimension();bi1++){
            bestIndividual.setEntry(bi1,bestind.getEntry(bi1));
        }
        //进化的代数
        for (int iter=0;iter<generationsPerRound;iter++) {
            for (int ind = 0; ind < popSize; ind++) {
                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];


                active = population.get(ind).toArray();
                activeFitness = population.get(ind).getEntry(population.getDimensions() - 1);
                F = population.getF(ind);
                CR = population.getCR(ind);

                do {
                    biIndex = rng.nextInt(numP);
                    biIndex = population.getIndexFromFitnessOrder(biIndex);
                } while (biIndex == ind);
                bi = population.get(biIndex);


                int[] randindex = RandSet.randomArray1(0, popSize - 1, 3, ind, biIndex);//生成3个不同的随机数


            /*do {
                rand1Index = (rng.nextInt(popSize));
            } while(rand1Index == biIndex || rand1Index == ind);*/
                rand1 = population.get(randindex[0]);

            /*do {
                rand2Index = (rng.nextInt(popSize));
            } while(rand2Index == ind || rand2Index == biIndex || rand2Index == rand1Index);*/
                rand2 = population.get(randindex[1]);

                int rand3Index = 0;
                RealVector rand3;
            /*do {
                rand3Index = (int) (Math.random() * popSize);
            } while(rand3Index == rand1Index || rand3Index == rand2Index || rand3Index == ind);*/
                rand3 = population.get(randindex[2]);

                for (int j = 0; j < dimensions; j++) {
                    double pom = (rand1.getEntry(j) - rand2.getEntry(j)) * F + rand3.getEntry(j);
                    //double pom = active[j] + F*(bi.getGene(j) - active[j]) + F * (rand1.getGene(j) - rand2.getGene(j));

                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getRandomValueInDomains(j);
                    }

                    noisy.addToEntry(j, pom);
                    double tr = (Math.random() < CR) ? noisy.getEntry(j) : active[j];
                    trial.addToEntry(j, tr);
                }

                trialFitness = function.compute(trial.toArray());
                trial.addToEntry(dimensions - 1, trialFitness);
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    //RealVector indiv = new ArrayRealVector(trial);
                    //indiv.setFitness(trialFitness);
                    population.set(ind, new ArrayRealVector(trial));//将第ind个个体替换掉
                    //population.set(ind, indiv);
                    SCR += CR;
                    nSCR++;
                    SF += F;
                    SF2 += F * F;
                }
                if (population.get(ind).getEntry(population.getDimensions() - 1) < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getEntry(dimensions - 1);
                }
            }

            population.updateuCR(SCR, nSCR);
            population.updateuF(SF, SF2);
        }
        return bestIndividual;
    }
}
