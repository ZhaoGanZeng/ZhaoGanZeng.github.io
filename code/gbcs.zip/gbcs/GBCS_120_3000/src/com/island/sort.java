package com.island;
import java.util.*;
/**
 * Created by hadoop on 15-7-4.
 */
public class sort {
    //arObjects为待排序的数组；
    /*
        arOrders待排序的列{0,1}:表示先根据第一列比较，若相同则再比较第二列
        {0}：表示按第一列进行排序
        升序
      */

    public static void sortIntArray(int[][] arObjects,final int[] arOrders)
    {
        Arrays.sort(arObjects, new Comparator<Object>()
        {
            public int compare(Object oObjectA, Object oObjectB)
            {
                int[] arTempOne = (int[])oObjectA;
                int[] arTempTwo = (int[])oObjectB;
                for (int i = 0; i < arOrders.length; i++)
                {
                    int k = arOrders[i];
                    if (arTempOne[k] > arTempTwo[k])
                    {
                        return 1;
                    }
                    else if (arTempOne[k] < arTempTwo[k])
                    {
                        return -1;
                    }
                    else
                    {
                        continue;
                    }
                }
                return 0;
            }
        });
    }
    public static void sortDoubleArray(double[][] arObjects,final int arOrders)
    {
        Arrays.sort(arObjects, new Comparator<Object>()
        {
            public int compare(Object oObjectA, Object oObjectB)
            {
                double[] arTempOne = (double[])oObjectA;
                double[] arTempTwo = (double[])oObjectB;
                //for (int i = 0; i < arOrders.length; i++)
                {
                    int k = arOrders;
                    if (arTempOne[k] > arTempTwo[k])
                    {
                        return 1;
                    }
                    else if (arTempOne[k] < arTempTwo[k])
                    {
                        return -1;
                    }
                    else
                    {
                       // continue;
                    }
                }
                return 0;
            }
        });
    }
}
