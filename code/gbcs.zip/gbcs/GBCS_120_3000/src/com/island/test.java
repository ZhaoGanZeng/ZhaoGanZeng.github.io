package com.island;

import scala.util.Random;

/**
 * Created by hadoop on 15-7-4.
 */
public class test {
    public static void main(String[] args)
    {
        double array[][] = new double[][] {
                {1, 12, 34, 68, 32, 9, 12, 545.1245678 },
                {2, 34, 72, 82, 57, 56, 0, 545.2245678 },
                {3, 12, 34, 68, 32, 21, 945, 23.2 },
                {4, 91, 10, 3, 23, 73, 34, 18.3 },
                {5, 12, 83, 189, 26, 27, 98, 33.5 },
                {6, 47, 23, 889, 24, 899, 23, 657.6 },
                {7, 12, 34, 68, 343, 878, 235, 768.1 },
                {8, 12, 34, 98, 56, 78, 12, 546.2 },
                {9, 26, 78, 2365, 78, 34, 256, 873.1 } };
        sort.sortDoubleArray(array, 7);    // 先根据第一列比较，若相同则再比较第二列

        for (int i = 0; i < array.length; i++)
        {
            for (int j = 0; j < array[i].length; j++)
            {
                System.out.print(array[i][j]);
                System.out.print("\t");
            }
            System.out.println();
        }
        //var r:Int = generator.nextInt(nAlgs)
        Random generator = new Random();
        System.out.println("随机数");
        for(int i=0;i<100;i++)
            System.out.println(generator.nextInt(6));
    }
}
