package com.island.SparkStrategies;


import scala.Serializable;

/**
 * Abstract class for island topologies
 * @author txj
 */
public abstract class Topology   implements Serializable {

    /**
     * Number of islands
     */
    protected int islandsNumber;

    /**
     * 
     * @param islands Number of islands
     */
    public Topology(int islands) {
        islandsNumber = islands;
    }

    /**
     * Get array of indexes of island for population to migrate to.
     * @param n index of curtent island
     * @return array of destination indexes
     */
    public abstract int[] get(int n);
    /*
      * @param n index of curtent island
      * @return array of Immigration indexes
     */
    public abstract int[] getImmigration(int n);

    //新加
    public  abstract int[] get_xing(int n);
    public  abstract int[] get_wang(int n);

}