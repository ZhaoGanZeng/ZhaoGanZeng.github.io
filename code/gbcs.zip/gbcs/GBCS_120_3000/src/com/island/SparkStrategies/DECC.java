package com.island.SparkStrategies;

import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class DECC {
	//public String fname; //
	//private String func_num;
	private int dim;
	//private double Lbound;
	//private double Ubound;
	private int popsize;
	private int itermax;
	private int fid;
	private SiPDEPopulation population;
	HashMap<Integer, List<Integer>> group;
	private Algorithm algorithm;
	public DECC(){
		
	}	 
	public DECC(Algorithm algorithm,int itermax,HashMap<Integer, List<Integer>> group){
		this.algorithm=algorithm;
		this.population=algorithm.population;
		this.popsize=algorithm.popSize;
		this.itermax=itermax;
		this.group=group;
	}
	public double run() throws IOException{
		double bestval=0.0;
		SiPDEIndividuals bestIndividual= null;

		bestIndividual= population.getBestIndividual();
		//最优个体的适应度
		//bestval=bestIndividual.getFitness();
		//当前最优个体的索引
		//int ibest=bestIndividual.getIndex();

		int group_num=group.size();
		int iter = 0;//控制循环的次数
		int sansde_iter = 100;//
		//进化代数
		itermax=itermax / group_num;
		//ArrayList<SiPDEIndividuals> subindividuals = null;
		//while(iter<this.itermax){

			System.out.println("第"+iter+"代");
			//对每一组进行优化
			for(int i=0;i<group_num;i++){
				/*int oneitermax=sansde_iter;
				if(iter+oneitermax>=itermax) {
					oneitermax=itermax-iter;
				}
				if(oneitermax==0){
					break;
				}
				iter=iter+oneitermax;*/
				/*
				从种群中获取下标为dim_index的子种群
				 */
				List<Integer> dim_index=group.get(i);
				//select pop from population where dim_index
				HashMap<Integer, RealVector> pop=population.getPopulation(dim_index);
				//System.out.println("pop的维度"+pop.get(0).getDimension());
				RealVector newbestind=bestIndividual.getGeno();
				bestval=bestIndividual.getFitness();
				ArrayList tracerst=new ArrayList();
				SubPopulation newsubpop= algorithm.generationCC(pop, newbestind, bestval, dim_index, itermax, tracerst);
				//将population中下标为dim_index的值替换掉
				//population.setp
				bestIndividual.setGeno(newsubpop.getBestind());
				bestIndividual.setFitness(newsubpop.getBestval());
				//newsubpop.getPop()
				population.setPopulation(newsubpop.getPop(),dim_index);
			}
			//population.evaluateAllIndividual();
			bestIndividual=population.getBestIndividual();
		//}
		return bestval;
	}
}
