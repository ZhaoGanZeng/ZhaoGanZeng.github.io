package com.island.SparkStrategies;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cec2010.Function;
import com.island.SparkStrategies.SiPDEPopulation;
import org.apache.commons.math3.linear.RealMatrix;

public class arr_islandPopulation {

    protected int arr_islandCount = 3;//分组岛个数

    protected Function function;
    public int dimensions;
    protected ArrayList<SiPDEIndividuals> individualsList = new ArrayList();
    protected RealMatrix pop;
    protected SiPDEIndividuals bestIndividual = null;
    protected boolean sorted = false;
    protected boolean migrationFlag;
    protected int key; //population key
    Random rng;
    protected double[] Fs; //F for every individual
    protected double[] CRs; //CR for every individual

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;

    public arr_islandPopulation(int D){
    Function function;
    int dimensions;
    ArrayList<SiPDEIndividuals> individualsList = new ArrayList();
    RealMatrix pop;
    SiPDEIndividuals bestIndividual = null;
    boolean sorted = false;
    boolean migrationFlag;
    int key; //population key
    Random rng;
    double[] Fs; //F for every individual
    double[] CRs; //CR for every individual

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;
    }

}
