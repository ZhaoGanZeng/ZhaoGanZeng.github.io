package com.island.SparkStrategies;

//import cec2010.Function;
import CEC2013.Function;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GBCS3 extends Algorithm{


    static protected double ndimensions; //个体维度
    static protected double pa; //外来卵的发现率/解决方案
    static protected double nfevalmax; //最大评价次数
    static protected Random rand;
    static protected double beta;
    static protected double pi,sigma,betap2,temp_u,temp_v,a;

    static protected double step,stepsize;
    static protected double pa_pool;
    int generations;
    protected int num_nest;      //巢穴个数
    /*static protected RealVector noisy,trial;
    static protected double trialFitness, activeFitness;*/

    public GBCS3(){

    }
    public GBCS3(Function f, int D_, int popSize_) {
        //super(f, D_, popSize_);
        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 5;

        beta = 1.5;
        pa=0.25;
        num_nest = popSize;
        ndimensions = 30;
        nfevalmax=10000*ndimensions;
        //sigma = 0;
        rand = new Random();
        pi = Math.PI;
        betap2 = Math.pow(2,(beta-1)/2);
        sigma = Math.pow((gamma(1+beta)*Math.sin(pi*beta/2)/(gamma((1+beta)/2)*beta*betap2)),(1/beta));
        do{
            pa_pool = Math.random();
        } while (pa_pool<0.01 || pa_pool>0.5 );

    }
    public GBCS3(Function f, int D_, int popSize_, int generationsPerRound) {
        this(f,D_,popSize_);
        this.generations=generationsPerRound;
    }

    public SiPDEIndividuals generation() throws Exception{
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            //Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        RealVector noisy,noisy2,noisy3;// =null; //new double[dimensions];
        RealVector trial,trial2,trial3;// =null;// new double[dimensions];

        double[] active,active_ran1,active_ran2;  //相当于matlab中的s
        //System.out.println("popSize="+popSize);
        double trialFitness, activeFitness,activeFitness_temp1,activeFitness_temp2;

        int biIndex1,biIndex2 = 0;
        double rand1,pa_temp;
        pa_temp = pa_pool;
        int scheme1 = rand.nextInt(2)+1;

        int iter=0;
        //CUDE的变异迭代策略
        while (iter<940 ) {//generations
            //iter = iter + num_nest;
            iter = iter + 1;
            for (int ind = 0; ind < popSize; ind++) {


                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];

                trial3 = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy3 = new ArrayRealVector(dimensions);//new double[dimensions];

                pa = pa_temp;
                active = population.get(ind).getGeno().toArray();
                //activeFitness = population.get(ind).getFitness();

                biIndex1 = rand.nextInt(popSize);
                activeFitness = population.get(biIndex1).getFitness();

                //随机选取种群中的适应度值与选取当前变异个体适应度值相结合
                /*biIndex1 = rand.nextInt(popSize);
                activeFitness_temp2 = population.get(biIndex1).getFitness();
                activeFitness_temp1 = population.get(ind).getFitness();
                if(Math.random()<1){
                    activeFitness = activeFitness_temp1;
                } else {
                    activeFitness = activeFitness_temp2;
                }*/


                //int scheme = get_cuckoos_scheme();

                int scheme = scheme1;


                SiPDEIndividuals best = null;

                switch (scheme) {
                    //高斯-布谷变异
                    case 1:
                        best = population.getBestIndividual();
                        for (int j = 0; j < dimensions; j++) {
                            double pom = ((best.getGene(j)+active[j])/2)+(Math.abs(best.getGene(j)-active[j]))*(Math.sqrt(1)*rand.nextGaussian());

                            if (pom < function.getMin()) { //
                                pom = function.getMin();
                            }else if (pom > function.getMax()){
                                pom = function.getMax();
                            }

                            noisy.addToEntry(j, pom);
                            trial.addToEntry(j,noisy.getEntry(j));
                        }
                        break;

                    //标准布谷变异(作为DE中的全局搜索？？？）
                    case 2:
                        best = population.getBestIndividual();
                        a = 0.2+0.05*( Math.sqrt(1)*rand.nextGaussian());
                        for (int j = 0; j < dimensions; j++) {
                            temp_u = (Math.sqrt(1)*rand.nextGaussian())*sigma;
                            temp_v = Math.sqrt(1)*rand.nextGaussian();
                            step = temp_u/Math.pow(Math.abs(temp_v),(1/beta));
                            stepsize = a*step*(active[j]-best.getGene(j));
                            double pom = active[j]+stepsize*(Math.sqrt(1)*rand.nextGaussian());

                            if (pom < function.getMin()) { //
                                pom = function.getMin();
                            }else if (pom > function.getMax()){
                                pom = function.getMax();
                            }

                            noisy.addToEntry(j, pom);
                            trial.addToEntry(j,noisy.getEntry(j));
                        }
                        break;
                }
                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                    scheme1 = scheme ;
                }else {
                    do{
                        scheme1 = get_cuckoos_scheme();
                    } while (scheme1==scheme);
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }

            }

            //新旧巢的保存创建
            int[] ran_ind1 = GBCS.random(popSize,popSize);
            int[] ran_ind2 = GBCS.random(popSize,popSize);
            for(int ind=0;ind<popSize;ind++){

                biIndex2 = rand.nextInt(popSize);
                activeFitness = population.get(biIndex2).getFitness();

                int ind1 = ran_ind1[ind];
                int ind2 = ran_ind2[ind];
                trial2 = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy2 = new ArrayRealVector(dimensions);//new double[dimensions];

                active = population.get(ind).getGeno().toArray();
                //activeFitness = population.get(ind).getFitness();

                active_ran1 = population.get(ind1).getGeno().toArray();

                active_ran2 = population.get(ind2).getGeno().toArray();

                //随机选取种群中的适应度值与选取当前变异个体适应度值相结合
                /*biIndex1 = rand.nextInt(popSize);
                activeFitness_temp2 = population.get(biIndex1).getFitness();
                activeFitness_temp1 = population.get(ind).getFitness();
                if(Math.random()<1){
                    activeFitness = activeFitness_temp1;
                } else {
                    activeFitness = activeFitness_temp2;
                }*/


                rand1 = Math.random();
                for (int d=0; d<dimensions;d++){
                    int k = ((Math.random()>pa) ? 1 : 0);
                    /*stepsize = Math.random()*(active_ran1[d]-active_ran2[d]);
                    double pom2 = active[d]+stepsize*k;*/
                    double pom2 = active[d]+(rand1*(active_ran1[d]-active_ran2[d]))*k;

                    if (pom2 < function.getMin()) { //
                        pom2 = function.getMin();
                    }else if (pom2 > function.getMax()){
                        pom2 = function.getMax();
                    }

                    noisy2.addToEntry(d, pom2);
                    trial2.addToEntry(d,noisy2.getEntry(d));

                }
                trialFitness = function.compute(trial2.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial2);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                    pa = pa_temp;;  //pa = pa_temp;
                }else {
                    do{
                        pa_pool = Math.random();
                    } while (pa_pool<0.01 || pa_pool>0.5 );
                    pa_temp = pa_pool;
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
        }

        bestFitness=population.getBestIndividual().getFitness();
        bestIndividual = population.getBestIndividual();
        //bestIndividual.geno;
        return bestIndividual;

    }

    public int get_cuckoos_scheme(){
        int scheme;
        if (Math.random()<0.5){
            scheme = 1;
        } else {
            scheme = 2;
        }
        return scheme;
    }



    //求解gamma函数值
    static double logGamma(double x) {
        double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
        double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
                + 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
                +  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
        return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
    }
    static double gamma(double x) {
        return Math.exp(logGamma(x));
    }

    /**
     * 随机生成n个不同的数
     *
     * @param amount
     *            需要的数量
     * @param max
     *            最大值(不含)，例：max为100，则100不能取到，范围为0~99；
     * @return 数组
     */
    public static int[] random(int amount, int max) { if (amount > max) {
        // 需要数字总数必须小于数的最大值，以免死循环！
        throw new ArrayStoreException( "The amount of array element must smallar than the maximum value !");
    } int[] array = new int[amount]; for (int i = 0; i < array.length; i++) {
        array[i] = -1; // 初始化数组，避免后面比对时数组内不能含有0。
    }
        Random random = new Random();
        int num; amount -= 1; // 数组下标比数组长度小1
        while (amount >= 0) {
            num = random.nextInt(max);
            if (exist(num, array, amount - 1)) {
                continue;
            }
            array[amount] = num;
            amount--;
        }
        return array;
    }
    /**
     * 判断随机的数字是否存在数组中
     *
     * @param num
     *            随机生成的数
     * @param array
     *            判断的数组
     * @param need
     *            还需要的个数
     * @return 存在true，不存在false
     */
    private static boolean exist(int num, int[] array, int need) { for (int i = array.length - 1; i > need; i--) {
        // 大于need用于减少循环次数，提高效率。
        if (num == array[i]) {
            return true;
        }
    }
        return false;
    }
    /**
     * 随机生成一个数
     *
     * @param max
     *            最大值(不含)
     * @return 整型数
     */
    public static int random(int max) {
        return random(1, max)[0];
    }



    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    @Override
    public SiPDEPopulation getPopulation() {
        // TODO Auto-generated method stub
        return population;
    }

    @Override
    public void newRound() {
        // TODO Auto-generated method stub

    }

    public void setParameter(String configName, double value) {
        /*// TODO Auto-generated method stub
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }*/
    }
}
