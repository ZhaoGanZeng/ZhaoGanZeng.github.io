package com.island.SparkStrategies;

import org.apache.commons.math3.linear.RealVector;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by hadoop on 17-7-25.
 */
public class SubPopulation {
    private HashMap<Integer, RealVector> pop;
    private RealVector bestind;
    private double bestval;
    private ArrayList tracerst;
    public SubPopulation(){
    }
    public SubPopulation(HashMap<Integer, RealVector> pop){
        this.pop=pop;
    }
    public SubPopulation(HashMap<Integer, RealVector> pop,RealVector bestind){
        this(pop);
        this.bestind=bestind;
    }
    public SubPopulation(HashMap<Integer, RealVector> pop,RealVector bestind,double bestval){
        this(pop,bestind);
        this.bestval=bestval;
    }
    public SubPopulation(HashMap<Integer, RealVector> pop,RealVector bestind,double bestval,ArrayList tracerst){
        this(pop,bestind,bestval);
        this.tracerst=tracerst;
    }


    public RealVector getBestind() {
        return bestind;
    }

    public void setBestind(RealVector bestind) {
        this.bestind = bestind;
    }

    public double getBestval() {
        return bestval;
    }

    public void setBestval(double bestval) {
        this.bestval = bestval;
    }

    public HashMap<Integer, RealVector> getPop() {
        return pop;
    }

    public void setPop(HashMap<Integer, RealVector> pop) {
        this.pop = pop;
    }

    public ArrayList getTracerst() {
        return tracerst;
    }

    public void setTracerst(ArrayList tracerst) {
        this.tracerst = tracerst;
    }
}
