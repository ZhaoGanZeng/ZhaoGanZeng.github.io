package com.island.SparkStrategies;


import CEC2013.Function;
import com.java.tools.RandSet;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author
 */
public class DE extends Algorithm { //DifEv

    //settings
    static protected double F = 0.1;   //F – mutacní konstanta [0, 2]
    //不断变异
    static protected double CR = 0.1;  //CR – práh krizení [0, 1]
    //越限
    public DE(){

    }

    public DE(Function f, int D_, int popSize_) {
        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);

        minPopulationSize = 5;
    }

    public SiPDEIndividuals generation() throws Exception{
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + "");
            }
        } catch (Exception ex) {
            Logger.getLogger(DE.class.getName()).log(Level.SEVERE, null, ex);
        }
        SiPDEIndividuals rand1, rand2, rand3;
        RealVector noisy;
        RealVector trial;

        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        double trialFitness, activeFitness;

        int iter=0;
        while (iter<100 ) {//generations
            iter = iter + 1;   //新加循环

            for (int ind = 0; ind < popSize; ind++) {
                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];

                active = population.get(ind).getGeno().toArray();//.getGenotype();
                activeFitness = population.get(ind).getFitness();

                //  Choose random individuals
                int[] randindex = RandSet.randomArray1(0, popSize - 1, 3, ind);//生成3个不同的随机数
                rand1 = population.get(randindex[0]);
                rand2 = population.get(randindex[1]);
                rand3 = population.get(randindex[2]);

                for (int j = 0; j < dimensions; j++) {
                    double pom = (rand1.getGene(j) - rand2.getGene(j)) * F + rand3.getGene(j);
                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
                    }
                    noisy.addToEntry(j, pom);
                    double tr = (Math.random() < CR) ? noisy.getEntry(j) : active[j];
                    trial.addToEntry(j, tr);
                }
                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                }

                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
        }

        return bestIndividual;
    }

    @Override
    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    public SiPDEPopulation getPopulation() {
        return population;
    }

    public void newRound() {
    }

    public void setParameter(String configName, double value) {
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
