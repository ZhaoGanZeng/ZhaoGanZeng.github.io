package com.island.SparkStrategies

import java.{lang, util}

import CEC2013.Common
import com.island.SparkStrategies.Topologies.Ring
import com.util._
import org.apache.spark.rdd.RDD
import org.apache.spark._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf, SparkContext}
import java.lang.reflect.Constructor

import com.island.SparkTest.SiPDECCTest.path

import scala.IndexedSeq
//重命名
import java.util.{HashMap => JHashMap}
import scala.collection.mutable.{ArrayBuffer, HashMap}
//import cec2010.{Randomizer, Function}
import CEC2013.Function
import java.util._
/**
  * Created by txj on 2017-06-22.
  */
class hzhDEDeaf extends java.io.Serializable {
  private var nMapTasks: Int = arr_islandCount//*islands  //3
  private[SparkStrategies] var VERBOSE: Boolean = false
  private[SparkStrategies] var WRITEHISTORY: Boolean = false
  private var defaultPopSize: Int = 0
  private[SparkStrategies] var islands: Int = 0
  private[SparkStrategies] var migrationRounds: Int = 0
  private[SparkStrategies] var round: Integer = 0
  var dimensions: Int = 0
  var migratingPopSize: Int = 1
  private[SparkStrategies] var generations: Int = 0
  private[SparkStrategies] var subPopulationSizes: util.ArrayList[Int] = new util.ArrayList[Int] {}
  private[SparkStrategies] var defaultPopulationAlgorithm: Class[_] = null
  private[SparkStrategies] var subPopulationAlgorithms: util.ArrayList[Class[_]] = new util.ArrayList[Class[_]]
  private var function: Class[_] = null
  private var algorithm: Algorithm = null;
  private var fInstance: Function = null
  private var configuredSubpopulations: Int = 0
  private var topology: Class[_] = classOf[Topology]
  private var immigrationMethod: SiPDEPopulation.acceptImmigrantsMethod = null
  private var emigrationMethod: SiPDEPopulation.expelEmigrantsMethod = null
  private[SparkStrategies] var DELETE_HISTORY: Boolean = true

  private[SparkStrategies] var RANDOM_ALGS_AND_PARAMS: Boolean = false

  //新加数据
  private[SparkStrategies] var arr_islandCount = 3
  private[SparkStrategies] var min:(Array[(Int, SiPDEPopulation)], Int)=null
  private var min_rdd:Int=0

  //有5个优化器
  private[SparkStrategies] var NO_OF_ALGORITHMS: Int = 6
  //起止时间
  var StartTime: Long = 0
  var EndTime: Long = 0
  var path = ""
  //config存放基本数据，比如：F、CR、
  //private var configDouble:HashMap[String,Double]=null
  private var configDouble: util.ArrayList[JHashMap[String, Double]] = new util.ArrayList[JHashMap[String, Double]]()
  //存放第i个岛存放的算法
  private var configAlg: JHashMap[Int, Algorithm] = new JHashMap[Int, Algorithm]()
  //存放第i个岛的种群大小
  private val configClass: JHashMap[Int, Int] = new JHashMap[Int, Int]()
  //private val genValue:util.ArrayList[Int,Double]=new util.ArrayList[Int,Double]()
  private val genValue: JHashMap[Int, Double] = new JHashMap[Int, Double]()
  var strArrayVar = ArrayBuffer((0, 0.0))

  private var subscript: JHashMap[Integer, List[Integer]] = new JHashMap[Integer, List[Integer]]

  var fun_num: Int = 0

  //object noarr_rdd: Array

  //private val NO_OF_ALGORITHMS:Int = 5
  /**
    *
    * @param fitFunction          FitnessFunction class implementation with optimalized fitness function.
    * @param D                    Number of dimensions of defined fitness function.
    * @param algorithm            Algorithm class implementation with computational algorithm for optimalization of fitness function
    * @param generationsPerRound  Number of generations (cycles of algorithm)
    * @param islandCount          Number of islands for populations. Equals number of Hadoop Map Tasks if not set with setMapTasks().
    * @param populationSize       Default size of populations if not set specifically.
    * @param migratingIndividuals Default number of migrating individuals if not set specifically.
    *                             fitFunction: Class[_ <: FitnessFunction]
    *                             algorithm: Class[_ <: Algorithm]
    */
  def this(temppath: String, fitFunction: Function, D: Int, algorithm: Algorithm, generationsPerRound: Int, islandCount: Int, populationSize: Int, migratingIndividuals: Int,f_num:Int) {
    this()
    this.path = temppath
    generations = generationsPerRound
    islands = islandCount
    defaultPopSize = populationSize
    nMapTasks = islandCount
    migratingPopSize = migratingIndividuals
    //immigrationMethod = SiPDEPopulation.acceptImmigrantsMethod.REPLACE_WORST
    //emigrationMethod = SiPDEPopulation.expelEmigrantsMethod.EXPEL_BEST
    //defaultPopulationAlgorithm = algorithm
    //val args:List[Int] = List{fitFunction;dimensions;defaultPopSize};
    //args = new Any{function dimensions popSize};
    /*以下调用带参的、私有构造函数*/
    //this.algorithm= algorithm.newInstance().asInstanceOf[Algorithm]
    //this.algorithm=algorithm.getDeclaredConstructor(AnyRef.getClass).newInstance(args).asInstanceOf[Algorithm]
    //this.algorithm=newInstanceObject.get(fitFunction,dimensions,defaultPopSize)
    this.algorithm = algorithm
    dimensions = D
    fun_num = f_num
    //function = fitFunction
    fInstance = fitFunction
    //将适应度函数进行分组
    //subscript = Randomizer.randIndexperm(fInstance)
    round = 0
  }

  //rdd数据集，为每个岛配置数据，传入rdd中，rdd{函数F1,种群个体}
  private def configureInitialization(sc: SparkContext): RDD[(Int,Array[(Int,SiPDEPopulation)])] = {
    //初始化种群
    //System.out.println("初始化种群"+nMapTasks+" "+islands+" "+defaultPopSize+" "+dimensions)
    val rdd = sc.parallelize(0 to arr_islandCount - 1, arr_islandCount).map(i => {
    val arr_island2 = Array(1,2,3,4,5)
      val arr_pop=arr_island2.map(r=>{
        val popSize: Int = defaultPopSize //每个岛中子群的数目
        //System.out.println("popSize="+popSize+";fInstance="+fInstance)
        val population: SiPDEPopulation = new SiPDEPopulation
        population.clear
        population.setFitnessFunction(fInstance) //设置函数；
        population.addRandomIndividuals(popSize, dimensions) //生成具体个体值,生成20个1000维个体，循环5次
        population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
        population.setKey(i) //设置岛的编号
        val arr=(r, population)
        arr
      })
      val arr2=(i,arr_pop)
      arr2
    }).cache()

    rdd

  }

  //直接创建法
  /*val arr_island1 = Array(1,2,3)
  val arr_island2 = Array(1,2,3,4,5)
  def arr1_rdd(fitFunction: Function, D: Int,generationsPerRound: Int)= {
      var arr2_rdd = arr_island1.map(i => {
          var arr3_rdd = arr_island2.map(r => {
              val popSize: Int = 20 //defaultPopSize //每个岛中子群的数目
              this.fInstance = fitFunction
              this.dimensions = D
              //System.out.println("popSize="+popSize+";fInstance="+fInstance)
              val population: SiPDEPopulation = new SiPDEPopulation
              population.clear
              population.setFitnessFunction(fInstance) //设置函数；
              population.addRandomIndividuals(popSize, dimensions) //生成具体个体值,生成20个1000维个体，循环5次
              population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
              population.setKey(r) //设置岛的编号
              (r, population)
          })
          (i, arr3_rdd)
      })
      arr2_rdd
  }*/

  val arr_island1 = Array(1,2,3)
  val arr_island2 = Array(1,2,3,4,5)
  def arr1_rdd(fitFunction: Function, D: Int,generationsPerRound: Int)={
    var arr2_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //每个岛中子群的数目
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //设置函数；
      population.addRandomIndividuals(popSize, dimensions) //生成具体个体值,生成20个1000维个体，循环5次
      population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
      population.setKey(r) //设置岛的编号
      (r, population)
    })

    var arr3_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //每个岛中子群的数目
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //设置函数；
      population.addRandomIndividuals(popSize, dimensions) //生成具体个体值,生成20个1000维个体，循环5次
      population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
      population.setKey(r) //设置岛的编号
      (r, population)
    })

    var arr4_rdd = arr_island2.map(r =>{
      val popSize: Int = 20//defaultPopSize //每个岛中子群的数目
      this.fInstance = fitFunction
      this.dimensions = D
      //System.out.println("popSize="+popSize+";fInstance="+fInstance)
      val population: SiPDEPopulation = new SiPDEPopulation
      population.clear
      population.setFitnessFunction(fInstance) //设置函数；
      population.addRandomIndividuals(popSize, dimensions) //生成具体个体值,生成20个1000维个体，循环5次
      population.resetIndividualsPopulation //如果生成个体下标是乱的，则重新排序
      population.setKey(r) //设置岛的编号
      (r, population)
    })
    val noarr_rdd =  Array(arr2_rdd,arr3_rdd,arr4_rdd)
   /* noarr_rdd(0).map(r=>{
    })*/
    val arr_rdd= noarr_rdd.zipWithIndex
    //Array(arr_rdd,noarr_rdd)
    arr_rdd
  }


  //val island:Unit = (1,2,3,4,5)
  //val arr_island = Array(1,2,3,4,5)
  private def arr_configureInitialization(sc: SparkContext): RDD[(Array[(Int,SiPDEPopulation)],Int)] = {  //Array[(Int,SiPDEPopulation)
    val arr5_rdd = arr1_rdd(fInstance, dimensions, generations)
    val arr_rdd=arr5_rdd
    /*val  noarr_rdd=arr5_rdd(1)
    val arr_rdd=arr5_rdd*/
    /* val fj_rdd = arr6_rdd
     val fj2_rdd = test_rdd1(fj_rdd)*/
    val rdd = sc.parallelize(arr_rdd,3).cache() //sc.parallelize(arr_rdd,islands)第一个参数是要并行化的数据集，第二个参数是将这个数据集切割成几分
    rdd
  }


  //从所有分组中寻找最优的个体
  private def findBest_arrayIndividual(rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) = {
    //private def findBestIndividual(rdd:RDD[(Int,SiPDEPopulation)]): (Int, SiPDEPopulation) = {
    //将rdd分组
    val arr6_rdd = rdd.map(r => {
      (r._2,r._1)
    })
    arr6_rdd
    //x，y代表分组rdd中的每一个分组
    val minrdd= arr6_rdd.reduce((x,y)=>{
      //x._2.map，将每个分组的岛的最优值找出，并保存到数组变量中
      val rbf_x:Array[Double]=x._1.map(population=>{
        var bf_x:Double = 0
        val rep_x=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_x<rep_x){
          bf_x = rep_x
        }
        bf_x
      })
      //找出所有岛的最优适应度值并赋值给bf_x
      val bf_x:Double=rbf_x.min
      val rbf_y:Array[Double]=y._1.map(population=>{
        var bf_y:Double = 0
        val rep_y=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_y<rep_y){
          bf_y = rep_y
        }
        bf_y
      })
      //找出所有岛的最优适应度值并赋值给bf_y
      val bf_y=rbf_y.min
      //每个分组的最优适应度值进行比较，找出最优的分组
      if(bf_x < bf_y){
        (x._1,x._2)
      }else{
        (y._1,y._2)
      }
    })
    //打印最优分组的最优适应度值
    var rep_fitness:Array[Double]=minrdd._1.map(fitness=>{
      var rep_fitness=fitness._2.getBestIndividual.getFitness
      rep_fitness
    })
    val besfFitness = rep_fitness.min
    //System.out.println(minrdd._1+"最优值为= "+minrdd._2.getBestIndividual.getFitness)
    System.out.println("minrdd._1是"+minrdd._2+"最优值为= "+besfFitness)
    minrdd

  }

  private def findBestIndividual(rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) = {
    //private def findBestIndividual(rdd:RDD[(Int,SiPDEPopulation)]): (Int, SiPDEPopulation) = {
    //将rdd分组
    val arr6_rdd = rdd.map(r => {
      (r._2,r._1)
    })
    arr6_rdd
    //x，y代表分组rdd中的每一个分组
    val minrdd= arr6_rdd.reduce((x,y)=>{
      //x._2.map，将每个分组的岛的最优值找出，并保存到数组变量中
      val rbf_x:Array[Double]=x._1.map(population=>{
        var bf_x:Double = 0
        val rep_x=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_x<rep_x){
          bf_x = rep_x
        }
        bf_x
      })
      //找出所有岛的最优适应度值并赋值给bf_x
      val bf_x:Double=rbf_x.min
      val rbf_y:Array[Double]=y._1.map(population=>{
        var bf_y:Double = 0
        val rep_y=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_y<rep_y){
          bf_y = rep_y
        }
        bf_y
      })
      //找出所有岛的最优适应度值并赋值给bf_y
      val bf_y=rbf_y.min
      //每个分组的最优适应度值进行比较，找出最优的分组
      if(bf_x < bf_y){
        (x._1,x._2)
      }else{
        (y._1,y._2)
      }
    })
    //打印最优分组的最优适应度值
    var rep_fitness:Array[Double]=minrdd._1.map(fitness=>{
      var rep_fitness=fitness._2.getBestIndividual.getFitness
      rep_fitness
    })
    val besfFitness = rep_fitness.min
    //System.out.println(minrdd._1+"最优值为= "+minrdd._2.getBestIndividual.getFitness)
    System.out.println("minrdd._1是"+minrdd._2+"最优值为= "+besfFitness)
    besfFitness
    /*var tem =ArrayBuffer[Double]()
    //var temp=tem.insert(i,besfFitness)
    tem += besfFitness
    var temp=tem.toArray
    temp*/
  }

   /*def array_findBestIndividual(rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],i:Int) = {
    //private def findBestIndividual(rdd:RDD[(Int,SiPDEPopulation)]): (Int, SiPDEPopulation) = {
    //将rdd分组
    val arr6_rdd = rdd.map(r => {
      (r._2,r._1)
    })
    arr6_rdd
    //x，y代表分组rdd中的每一个分组
    val minrdd= arr6_rdd.reduce((x,y)=>{
      //x._2.map，将每个分组的岛的最优值找出，并保存到数组变量中
      val rbf_x:Array[Double]=x._1.map(population=>{
        var bf_x:Double = 0
        val rep_x=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_x<rep_x){
          bf_x = rep_x
        }
        bf_x
      })
      //找出所有岛的最优适应度值并赋值给bf_x
      val bf_x:Double=rbf_x.min
      val rbf_y:Array[Double]=y._1.map(population=>{
        var bf_y:Double = 0
        val rep_y=population._2.getBestIndividual.getFitness  //rbf:replace_bestFitness需要替换的
        if(bf_y<rep_y){
          bf_y = rep_y
        }
        bf_y
      })
      //找出所有岛的最优适应度值并赋值给bf_y
      val bf_y=rbf_y.min
      //每个分组的最优适应度值进行比较，找出最优的分组
      if(bf_x < bf_y){
        (x._1,x._2)
      }else{
        (y._1,y._2)
      }
    })
    //打印最优分组的最优适应度值
    var rep_fitness:Array[Double]=minrdd._1.map(fitness=>{
      var rep_fitness=fitness._2.getBestIndividual.getFitness
      rep_fitness
    })
    val besfFitness = rep_fitness.min
    //System.out.println(minrdd._1+"最优值为= "+minrdd._2.getBestIndividual.getFitness)
    System.out.println("minrdd._1是"+minrdd._2+"最优值为= "+besfFitness)
    besfFitness
     var tem =ArrayBuffer[Double]()
     var temp=tem.insert(i,besfFitness)
     tem

  }*/

  def test_rdd1(arr7_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])]) ={

    /* /*var oldRdd=arr_rdd2.map(r => {
         (r._1,r._2)
     })
     oldRdd*/
     //var oldRdd=arr_rdd2.map(r=>{
         val arr_rdd3=arr_rdd2.reduce((n,m) => {
             (n._1,n._2)
     })
     val arr_rdd4=arr_rdd2.reduce((n,m) => {
         (m._1,m._2)
     })
     /*val arr_rdd5=arr_rdd2.reduce((n,m) => {
         if(n._1<m._1){
             (m._1,m._2)
         }


     })*/
     val rdd6=arr_rdd3.*/

    /*val rdd1= arr7_rdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，
      val hzh:Int=6
      //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
      val arr_population=r._1.map(population =>{  //(x=>x.map(x=>x*2))
        val arr_population=population._2
        algorithm.setPopulation(arr_population)
        arr_population.resetIndividualsPopulation()//重置个体种群，20个
        //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
        algorithm.setParameter("F",configDouble.get(r._2).get("F"))
        algorithm.setParameter("CR",configDouble.get(r._2).get("CR"))
        //generationsPerRound=generations//每个子种群中的进化代数
        //islands
        val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
        val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
        (population,pop)//,strArrayVar，pop包含的是种群数据
      })
      (r,arr_population)
    })
    rdd1
    val m:Int=7*/


    /*val rdd1= arr7_rdd.flatMap(r=>
        r._1.map(population=>{
            //这一步骤是为每个岛赋值F，CR值，
            //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
            val arr_population=population._2
            algorithm.setPopulation(arr_population)
            arr_population.resetIndividualsPopulation()//重置个体种群，20个
            //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
            algorithm.setParameter("F",configDouble.get(r._2).get("F"))
            algorithm.setParameter("CR",configDouble.get(r._2).get("CR"))
            //generationsPerRound=generations//每个子种群中的进化代数
            //islands
            val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
            val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
            (population,pop)//,strArrayVar，pop包含的是种群数据
        })*/
    /*val rdd2=arr5_rdd.take(1)
    val rdd3=rdd2.take(1)*/
    /* val rdd1= arr5_rdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，
         val hzh:Int=6
         r
         //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
                    // val arr_population:Array[(Int,SiPDEPopulation)]=r
            val arr_population = r._2
             arr_population.reverseMap(population=>{

                 algorithm.setPopulation(population._2)
                 population._2.resetIndividualsPopulation()//重置个体种群，20个
                 //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
                 algorithm.setParameter("F",configDouble.get(r._1).get("F"))
                 algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
                 //generationsPerRound=generations//每个子种群中的进化代数
                 //islands
                 val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
                 val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
                 (population,pop)//,strArrayVar，pop包含的是种群数据
             })
         (r,arr_population)
     })
     rdd1
     val m:Int=7
 }*/

    /*val arr8_rdd=arr7_rdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，

      //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
      // val arr_population:Array[(Int,SiPDEPopulation)]=r
      val arr_population = r._1//.take(1)
      val arr_pop=arr_population(2)  //是sipdepopulation
     /* arr_population.map(population=>{
        val h=population._1.take(1)
        val c=h(2)
        c._2*/
      //r._2.collect[(Int,SiPDEPopulation),SiPDEPopulation]
      //arr_population.map(population=>{
        algorithm.setPopulation(arr_pop._2)
        arr_pop._2.resetIndividualsPopulation()//重置个体种群，20个
        //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
        algorithm.setParameter("F",configDouble.get(r._2).get("F"))
        algorithm.setParameter("CR",configDouble.get(r._2).get("CR"))
        //generationsPerRound=generations//每个子种群中的进化代数
        //islands
        val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
        val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
        val arr=(r._1(2)._1,pop)//,strArrayVar，pop包含的是种群数据
      (arr,r._2)
      //})
      /*val fin_rdd =(r._1,arr_population)
      System.out.println(fin_rdd._1)*/
    })//.cache()
    // arr5_rdd.takeSample(false,1,)
    //val x=arr7_rdd.count()
    arr8_rdd
    val m:Int=7*/
  }


  private def printBestIndividual(winner: (Int, SiPDEPopulation)) {
    if (winner == null) {
      System.out.println("---- Unable to print best individual !")
    }
    else {
      System.out.println("---- Best so far : \n" + winner._2.getBestIndividual.getFitness)
    }
  }

  def createRandomPopulation(sc: SparkContext): RDD[(Int,Array[(Int,SiPDEPopulation)])] = {  //Array[(Int,SiPDEPopulation)]
    val arr_rdd=configureInitialization(sc)//配置初始种群
    //val arr_rdd = arr_configureInitialization(sc)
    /*rdd.foreach{x=>{
        println("岛的编号："+x._1+";x="+x._2.getBestIndividual.getFitness)
    }}*/
    //val bestInd: (Int, arr_islandPopulation) = findBestIndividual(rdd)//寻找最优个体
    val bestInd: (Array[(Int,SiPDEPopulation)],Int) = findBest_arrayIndividual(arr_rdd)

    //val test_rdd: (Unit)= test_rdd1(arr_rdd)
    //printBestIndividual(bestInd)
    arr_rdd
  }
  /*def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int):((Int,Array[(Int,SiPDEPopulation)]))= {
      val test_rdd: RDD[((Int,Array[(Int,SiPDEPopulation)]))] = test_rdd1(arr_rdd)
  }*/
  val bestInd: (Array[(Int,SiPDEPopulation)],Int) = null
  def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int)= {
    /*var oldRdd=arr_rdd.map(r=>{  //:RDD[(Int,Array[(Int,SiPDEPopulation)])]
      val population=r._2
      (r._1,population)
    })*/
    //val arr6_rdd = arr1_rdd(fInstance, dimensions, generations)
    //val test_rdd = test_rdd1(oldRdd)//.cache() //RDD[((Int,Array[(Int,SiPDEPopulation)]))]
    var generationsPerRound: Int = 0
    var oldRdd=arr_rdd
    var  topology:Topology =new Ring(islands); //覆盖了SiPDECCTest中的topology：Ring_1_2，变成Ring
    //val path =  //"/home/hadoop/sparkCUDEResult/resultCUDEisland20161122"
    var tempvalue=""
    val tempvalue1 = " F" + (fun_num) +"  run " +  "  " + " Slices " + "\n"
    Common.appendMethodB(path, tempvalue1)//存储数据
    //var genValue=null
    for (i <-0 to round-1) {//round=30
      //迁入的种群
      //var immigrants: RDD[(Int, SiPDEPopulation)] = oldRdd
      //immigrants=oldRdd
      //进化的种群
      //val array=ArrayBuffer()
      //将oldRdd分解
      System.out.println("第"+i+"轮")
      /* val arr8_rdd=oldRdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，
      //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
      // val arr_population:Array[(Int,SiPDEPopulation)]=r
      val arr_population = r._1//.take(1)
      val arr_pop=arr_population  //是sipdepopulation
      algorithm.setPopulation(arr_pop(2)._2)
      arr_pop(2)._2.resetIndividualsPopulation()//重置个体种群，20个
      //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
      algorithm.setParameter("F",configDouble.get(r._2).get("F"))
      algorithm.setParameter("CR",configDouble.get(r._2).get("CR"))
      //generationsPerRound=generations//每个子种群中的进化代数
      //islands
      val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
      val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
      val arr=(r._1(2)._1,pop)//,strArrayVar，pop包含的是种群数据
      val arr9_rdd=(Array(arr),r._2)
      arr9_rdd
    })
    arr8_rdd*/
        /*if(RANDOM_ALGS_AND_PARAMS){
          //f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int
          setRandomAlgAndParams1(algorithm.function,algorithm.dimensions,algorithm.popSize,islands, NO_OF_ALGORITHMS,generationsPerRound);
        }*/
      val arr8_rdd=oldRdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，
        //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中

          if(false){//RANDOM_ALGS_AND_PARAMS=true
            //第0轮不计入
            /*if(i>=1){
              min_rdd=min._2
            } else {
              min_rdd=1
            }*/
            this.NO_OF_ALGORITHMS=2//r._1
            setRandomAlgAndParams1(algorithm.function,algorithm.dimensions,algorithm.popSize,islands, NO_OF_ALGORITHMS,generationsPerRound,i,min_rdd);
          }
        val arr_population = r._2//每次取出一个岛分组
        //var arr:Array[(Int,SiPDEPopulation)]=new Array[(Int,SiPDEPopulation)]
        val arr1_pop=arr_population.map(arr2_pop=>{
          algorithm.setPopulation(arr2_pop._2)
          arr2_pop._2.resetIndividualsPopulation()//重置个体种群，20个
          //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
          algorithm.setParameter("F",configDouble.get(r._1).get("F"))
          algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
          val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次
          val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
          var arr3=(arr2_pop._1,pop)//？？？
          //val arr9_rdd=(Array(arr),arr_pop._1)
          arr3
        })  //是sipdepopulation
        var arr9_rdd=(r._1,arr1_pop)
        arr9_rdd
      })
      var arr10_rdd=arr8_rdd
  //注释了一下
  //var bestInd: (Int, SiPDEPopulation) = null
  //round=30 generationsPerRound=100
    /* def run(arr_rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],round:Int,arr_islandCount:Int):((Int,Array[(Int,SiPDEPopulation)]))={
       //最优个体
       //val bestInd: SiPDEPopulation =null
       var generationsPerRound: Int = 0
       var oldRdd=arr_rdd
       //var bestInd: (Int, SiPDEPopulation)=null
       //System.out.println("轮数为"+round)
       //迁移的拓扑结构
       var  topology:Topology =new Ring(islands); //覆盖了SiPDECCTest中的topology：Ring_1_2，变成Ring
       //val path =  //"/home/hadoop/sparkCUDEResult/resultCUDEisland20161122"
       var tempvalue=""
       val tempvalue1 = " F " + (fInstance.getClass.getName) +"  run " +  "  " + " Slices " + "\n"
       Common.appendMethodB(path, tempvalue1)//存储数据
       //var genValue=null
       for (i <-0 to round-1) {//round=30
           //迁入的种群
           //var immigrants: RDD[(Int, SiPDEPopulation)] = oldRdd
           //immigrants=oldRdd
           //进化的种群
           //val array=ArrayBuffer()
           //将oldRdd分解
           System.out.println("第"+i+"轮")
           val rdd1= oldRdd.map(r=>{ //这一步骤是为每个岛赋值F，CR值，
               if(RANDOM_ALGS_AND_PARAMS){
                   //f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int
                   setRandomAlgAndParams1(algorithm.function,algorithm.dimensions,algorithm.popSize,islands, NO_OF_ALGORITHMS,generationsPerRound);
               }
               //r._1是岛编号，r._2是每个岛包含个体,20,把F，CR传入每个岛的算法中
               val arr_population=r._2.map(population =>{
                   val arr_population=population._2
               algorithm.setPopulation(arr_population)
               arr_population.resetIndividualsPopulation()//重置个体种群，20个
               //获取每个岛的F，CR值，赋值给algorithm中的F，CR值,,  algorithm中没有F，CR两个属性？？？？
               algorithm.setParameter("F",configDouble.get(r._1).get("F"))
               algorithm.setParameter("CR",configDouble.get(r._1).get("CR"))
               //generationsPerRound=generations//每个子种群中的进化代数
               //islands
               val sipdeindividuals:SiPDEIndividuals= algorithm.generation(); //调用CUDE.generation()方法,变异，交叉，迭代940次

               //下面的代码为没有分解时的进化 DGCC
               /*if(subscript.size()==1){
                   for(j<-0 to generationsPerRound-1){

                       algorithm : Algorithm,population : SiPDEPopulation,popsize : Int,
                       itermax : Int,group : HashMap[Integer, List[Integer]]
                       val sipdeindividuals:SiPDEIndividuals= algorithm.generation();
                   }

               }else {
                   //System.out.println("subscript=="+subscript.size())
                   val decc: DECC = new DECC(algorithm, generationsPerRound, subscript);
                   var newvalue = decc.run();
               }*/
               //System.out.println("第"+r._1+"岛的最优值为"+newvalue)

               //algorithm.getPopulation.setPopulation()
               val pop=algorithm.getPopulation //获取algorithm中的population属性，包含function、pop、bestind，FS、CRS等
                   (r._1,(population._1,pop))//,strArrayVar，pop包含的是种群数据
               })
           })
           //待修改的地方
           /*System.out.println("map之中strArrayVar==")
           strArrayVar.foreach(print)
           System.out.println("map之中strArrayVarx.3==")

           //求rdd1中genValue值最小的  还没有改好？x._3.get(x._1),
           System.out.println("map之中的genValue为x.3==")
           System.out.println("strArrayVar=="+strArrayVar.size)

           var tempRdd=rdd1.map(x=>{
               var res = List[(Int, Double)]()
               for (item <- x._3){
                   res.::=(item._1,item._2)
               }
               (res)
           }).collect()//.foreach(print)*/
           //迁出的种群  提出最优个体 */
      //var arr10_rdd=arr8_rdd//.collect()//.take(3)//.collect()

      /*//emigrants2是进行每个分组的岛间的交换
      val emigrants2:RDD[(Int,Array[(Int,SiPDEPopulation)])]=arr8_rdd.map(arr=> {
        val arr_population = arr._1
        val arr1_emig = arr_population.map(ind => {
          //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
          val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
          arr2_emig
        })
        val arr9_rdd=(arr._2,arr1_emig)
        arr9_rdd
      })
      val partitioner2=new SiPDEPartitioner_1(emigrants2,topology,arr_islandCount,islands,immigrationMethod)
      val rdd3=arr8_rdd.map(r=>{
        (r._1,r._2)
      }).partitionBy(partitioner2).cache()

      //emigrants1是进行分组间的交换
      val emigrants1:RDD[(Int,Array[(Int,SiPDEPopulation)])]=rdd3.map(arr=> {
        val arr_population = arr._1
        val arr1_emig = arr_population.map(ind => {
          //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
          val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
          arr2_emig
        })
        val arr9_rdd=(arr._2,arr1_emig)
        arr9_rdd
      })
      //val rdd12=emigrants.map(r=>{
      //SiPDEPartitioner是进行分组间的交换
      val partitioner1=new SiPDEPartitioner(emigrants1,topology,arr_islandCount,islands,immigrationMethod)
      val rdd2=rdd3.map(r=>{
        (r._1,r._2)
      }).partitionBy(partitioner1).cache()*/

      //emigrants1是进行分组间的交换
      val emigrants1:RDD[(Int,Array[(Int,SiPDEPopulation)])]=arr10_rdd.map(arr=> {
        val arr_population = arr._2
        val arr1_emig = arr_population.map(ind => {
          //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
          val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
          arr2_emig
        })
        val arr11_rdd=(arr._1,arr1_emig)
        arr11_rdd
      })
      //SiPDEPartitioner是进行分组间的交换
      val partitioner1=new SiPDEPartitioner_wang(emigrants1,topology,arr_islandCount,islands,immigrationMethod)
      val rdd2=arr10_rdd.map(r=>{
        (r._2,r._1)
      }).partitionBy(partitioner1).cache()

      //emigrants1是进行每个分组的岛间的交换
      /*val emigrants2:RDD[(Int,Array[(Int,SiPDEPopulation)])]=rdd2.map(arr=> {
        val arr_population = arr._1
        val arr1_emig = arr_population.map(ind => {
          //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
          val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
          arr2_emig
        })
        val arr9_rdd=(arr._2,arr1_emig)
        arr9_rdd
      })
      val partitioner2=new SiPDEPartitioner_1(emigrants2,topology,arr_islandCount,islands,immigrationMethod)
      val rdd3=rdd2.map(r=>{
        (r._1,r._2)
      }).partitionBy(partitioner2).cache()*/


      //将迁出的种群传递到分区函数中
        oldRdd=rdd2.map(r=>{
          (r._2,r._1)
        })


        /* val arr9_rdd=oldRdd.collect()
         val arr10_rdd=arr9_rdd(1)
         arr10_rdd*/
      //})
      /*val partitioner=new SiPDEPartitioner(emigrants,topology,arr_islandCount,islands,immigrationMethod)
       val rdd2=arr8_rdd.map(r=>{
         (r._2,r._1)
       }).partitionBy(partitioner).cache()
       //将迁出的种群传递到分区函数中
       oldRdd=rdd2.map(r=>{
         (r._2,r._1)
       })*/
                //val partitioner=new SiPDEPartitioner(arr_emig,topology,islands,immigrationMethod)
                /*(arr1_emig,arr._2)
                val arr_pop=arr_population(2)
                val emig=arr_pop._2.getEmigrants(migratingPopSize,emigrationMethod)
                val arr_emig=(emig,arr._1(1)._1)
             val arr3_emig=(arr1_emig,arr._2)
             //val arr3_emig=(arr2_emig,arr._2)
             arr3_emig
           })*///val emigrants---此，

      /*val emigrants:RDD[(Array[(Int,SiPDEPopulation)],Int)]=arr8_rdd.map(arr=> {

        val arr_population = arr._1
        val arr1_emig:Array[(Int,SiPDEPopulation)]= arr_population.map(ind => {
          //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
          val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
          emig.resetIndividualsPopulation();
          //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
          val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
          arr2_emig
        })

        val partitioner = new SiPDEPartitioner(arr1_emig, topology, arr_islandCount, islands, immigrationMethod)
        val arr2_emig=arr1_emig
        arr2_emig
        val rdd2 = arr2_emig.map(r => {
          (r._2,r._1)
        }).partitionBy(partitioner).cache()

        //将迁出的种群传递到分区函数中
        oldRdd = rdd2.map(r => {
          (r._2, r._1)
          })
        val arr12=oldRdd.collect()(1)
        arr12
        })
        val partitioner = new SiPDEPartitioner(arr1_emig, topology, arr_islandCount, islands, immigrationMethod)
        val arr2_emig=arr1_emig
        arr2_emig
        val rdd2 = arr2_emig.map(r => {
          (r._2,r._1)
        }).partitionBy(partitioner).cache()

        //将迁出的种群传递到分区函数中
        oldRdd = rdd2.map(r => {
          (r._2, r._1)
        })
        val arr12=oldRdd.collect()(1)
        arr12
        val arr_emigrants=emigrants
           //替换最差个体,emigrants包含岛编号和要替换的15个个体，topology,用15个好的个体替换其他岛的15个最差的个体
           //应该新建类
           val partitioner=new SiPDEPartitioner_1(arr_emigrants,topology,arr_islandCount,islands,immigrationMethod)
           val rdd2=arr8_rdd.map(r=>{
               (r._2,r._1)
           }).partitionBy(partitioner).cache()
           //将迁出的种群传递到分区函数中
           oldRdd=rdd2.map(r=>{
               (r._2,r._1)
           })
        */

      /*val emigrants:RDD[(Int,SiPDEPopulation)]=arr8_rdd.map(arr=> {
        val arr_population = arr._1
        //val arr1_emig=arr_pop(arr_population)
        //def arr_pop(array: Array[(Int,SiPDEPopulation)]) = {
          val arr1_emig = arr_population.map(ind => {
            //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
            val emig = ind._2.getEmigrants(migratingPopSize, emigrationMethod)
            emig.resetIndividualsPopulation();
            //emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
            val arr2_emig = (ind._1, emig) //r._1：岛编号，emig：15个迁移个体
            arr2_emig
          })
        //}
        val ar=(arr._2,arr1_emig)
        ar
      })

        val partitioner = new SiPDEPartitioner(arr1_emig, topology, arr_islandCount, islands, immigrationMethod)
        val arr2_emig=arr1_emig
        arr2_emig
        val rdd2 = arr2_emig.map(r => {
          (r._2,r._1)
        }).partitionBy(partitioner).cache()

        //将迁出的种群传递到分区函数中
        oldRdd = rdd2.map(r => {
          (r._2, r._1)
        })
        val arr12=oldRdd.collect()(1)
        arr12
        val arr_emigrants=emigrants
           //替换最差个体,emigrants包含岛编号和要替换的15个个体，topology,用15个好的个体替换其他岛的15个最差的个体
           //应该新建类
           val partitioner=new SiPDEPartitioner_1(arr_emigrants,topology,arr_islandCount,islands,immigrationMethod)
           val rdd2=arr8_rdd.map(r=>{
               (r._2,r._1)
           }).partitionBy(partitioner).cache()
           //将迁出的种群传递到分区函数中
           oldRdd=rdd2.map(r=>{
               (r._2,r._1)
           })*/
      /*oldRdd=run2(arr8_rdd)
      def run2(arr10_rdd:RDD[(Array[(Int,SiPDEPopulation)],Int)])={
        var arr11_rdd=arr10_rdd//.take(3)//.collect()
        val emigrants:RDD[(Array[(Int,SiPDEPopulation)],Int)]=arr10_rdd.map(arr=>{
          val arr_population = arr._1
          val arr_emig=arr_population.map(ind=>{
            //migratingPopSize=15,emigrationMethod=EXPEL_BEST,获取了15个要迁移的个体
            val emig=ind._2.getEmigrants(migratingPopSize,emigrationMethod)
            emig.resetIndividualsPopulation();//emig包含15个要迁移的个体,给15个个体重新赋值下标,0-14
            (ind._1,emig)//r._1：岛编号，emig：15个迁移个体
          })
          //val partitioner=new SiPDEPartitioner(arr_emig,topology,islands,immigrationMethod)
          (arr_emig,arr._2)
          /*val arr_pop=arr_population(2)
          val emig=arr_pop._2.getEmigrants(migratingPopSize,emigrationMethod)
          val arr_emig=(emig,arr._1(1)._1)
       val arr2_emig=(arr_emig,arr._2)*/
        })//val emigrants---此，
        //替换最差个体,emigrants包含岛编号和要替换的15个个体，topology,用15个好的个体替换其他岛的15个最差的个体
        /*val partitioner=new SiPDEPartitioner(emigrants,topology,islands,immigrationMethod)
        val rdd2=arr10_rdd.map(r=>{
          (r._2,r._1)
        }).partitionBy(partitioner).cache()
        //将迁出的种群传递到分区函数中
        oldRdd=rdd2.map(r=>{
          (r._2,r._1)
        })*/
        oldRdd
      }*/





           //System.out.print("rdd2.partitioner:"+rdd2.partitioner)
           StartTime=System.currentTimeMillis()
           min = findBest_arrayIndividual(arr8_rdd)  //new
           var rep_fitness:Array[Double]=min._1.map(fitness=>{
            var rep_fitness=fitness._2.getBestIndividual.getFitness
            rep_fitness
          })
           val temp_besfFitness = rep_fitness.min
           System.out.println("minrdd._1是"+min._2+"最优值为= "+temp_besfFitness)
           temp_besfFitness
           tempvalue += (i+1)+" "+temp_besfFitness
           /*var tempbestInd = findBestIndividual(arr8_rdd)
           tempvalue += (i+1)+" "+tempbestInd*/
           EndTime=System.currentTimeMillis()
           tempvalue+= " "+(EndTime - StartTime)+" \n"
           System.out.println(tempvalue);


       }
       //输出最优的值
       val bestInd = findBest_arrayIndividual(arr_rdd)
       //tempvalue+=bestInd._2.getBestIndividual.getFitness
       Common.appendMethodB(path, tempvalue)
       //printBestIndividual(bestInd)
       bestInd
     //arr8_rdd
    }
  //override def partitionBy(partitioner : org.apache.spark.Partitioner):  org.apache.spark =
  def getRound: Int = {
    round
  }

  def setRound(nr: Int) {
    val round = nr
  }

  def getGenValue(): JHashMap[Int, Double] ={
    genValue
  }

  /***
    count为岛的数目
    nAlgs为算法的种类
    **/
  def setRandomAlgAndParams(count:Int, nAlgs:Int) {
    var generator:Random = new Random();
    for (i <- 0 to count) {
      var r:Int = generator.nextInt(nAlgs)
      var names:String = ""
      //var alg  //Class[_ <:Algorithm]
      var F=0.0
      var CR=0.0
      var printArgs:String = "";
      r match {
        case 0=>
          var alg = new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 1=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 2=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 3=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case 4=>
          var alg =new GBCS
          configAlg.put(i,alg)
          F = generator.nextFloat()*2;
          CR = generator.nextFloat();
          val subpopParameters = new JHashMap[String, Double]();
          subpopParameters.put("F", F)
          subpopParameters.put("CR", CR)
          configDouble.add(i,subpopParameters)
        case _=> println("error");
      }
      //System.out.println("---- " + "Algorithm " + i + ": " + alg);
      //System.out.println(printArgs);
      //  Set algorithm specific for this subpopulations
      //configAlg.put(i,alg)
      //  Set size of subpopulation
      configClass.put(i,defaultPopSize)
      //conf.setInt("popSize_" + i, defaultPopSize); //------?
    }
  }
  /***
    count为岛的数目
    nAlgs为算法的种类
    **/
  /*def setRandomAlgAndParams1(f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int,generationsPerRound:Int) {
    var generator:Random = new Random();
    for (i <- 0 to count) {
      var r:Int = generator.nextInt(nAlgs)
      var names:String = ""
      var F=0.0
      var CR=0.0
      var printArgs:String = "";
      r match {
        case 0=>
          var alg = new CUDE1(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 1=>
          var alg = new CUDE2(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 2=>
          var alg = new CUDE3(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 3=>
          var alg = new CUDE4(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 4=>
          var alg = new CUDE5(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 5=>
          var alg = new CUDE6(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
      }
      //this.algorithm=alg
      //System.out.println("---- " + "Algorithm " + i + ": " + alg);
      //System.out.println(printArgs);
      //  Set algorithm specific for this subpopulations
      //configAlg.put(i,alg)
      //  Set size of subpopulation
      configClass.put(i,defaultPopSize)
      //conf.setInt("popSize_" + i, defaultPopSize); //------?
    }
  }*/
  //修改调用方法
  def setRandomAlgAndParams1(f: Function, D_ : Int, popSize_ : Int,count:Int, nAlgs:Int,generationsPerRound:Int,I:Int,min_rdd:Int) {
    var generator:Random = new Random();
    for (i <- 0 to count) {
      var r:Int = nAlgs//generator.nextInt(nAlgs)
      var names:String = ""
      var F=0.0
      var CR=0.0
      var printArgs:String = "";
      r match {  //hzh1是原生态策略，hzh2是两个策略，hzh3是6个策略
        /*case 0=>
          var alg = new JADE1(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 1=>
          var alg = new JADE1(f,D_,popSize_,generationsPerRound) //CUDE4是DEBest1bin

          this.algorithm=alg
        case 2=>
          var alg = new JADE1(f,D_,popSize_,generationsPerRound)//CUDE6是DECurrentToBest
          this.algorithm=alg*/

        case 0=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound)  //DECurrentToPBest
          this.algorithm=alg
        case 1=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound) //CUDE4是DEBest1bin  //CUDE

          this.algorithm=alg
        case 2=>
          var alg = new GBCS(f,D_,popSize_,generationsPerRound)//CUDE6是DECurrentToBest  JADE1
          this.algorithm=alg

        /*case 0=>
          var alg = new CUDE1_hzh2(f,D_,popSize_,generationsPerRound,I,min_rdd)
          this.algorithm=alg
        case 1=>
          var alg = new CUDE3_hzh2(f,D_,popSize_,generationsPerRound,I,min_rdd) //CUDE4是DEBest1bin

          this.algorithm=alg
        case 2=>
          var alg = new CUDE5_hzh2(f,D_,popSize_,generationsPerRound,I,min_rdd)//CUDE6是DECurrentToBest
          this.algorithm=alg*/

        /*case 0=>
          var alg = new CUDE1_hzh(f,D_,popSize_,generationsPerRound)
          this.algorithm=alg
        case 1=>
          var alg = new CUDE3_hzh(f,D_,popSize_,generationsPerRound) //CUDE4是DEBest1bin

          this.algorithm=alg
        case 2=>
          var alg = new CUDE5_hzh(f,D_,popSize_,generationsPerRound)//CUDE6是DECurrentToBest
          this.algorithm=alg*/

      }
      //this.algorithm=alg
      //System.out.println("---- " + "Algorithm " + i + ": " + alg);
      //System.out.println(printArgs);
      //  Set algorithm specific for this subpopulations
      //configAlg.put(i,alg)
      //  Set size of subpopulation
      configClass.put(i,defaultPopSize)
      //conf.setInt("popSize_" + i, defaultPopSize); //------?
    }
  }

  /**
    * Sets algorithms according to their ratings...
    */
  def setRatedAlgorithms {
  }

  /**
    *
    * @param top Topology extending class defining the topology of islands (determines the destination island for migrating population)
    */
  def setTopology(top: Class[_ <: Topology]) {
    topology = top
  }
  def setRANDOM_ALGS_AND_PARAMS(RANDOM_ALGS_AND_PARAMS:Boolean): Unit ={
    this.RANDOM_ALGS_AND_PARAMS=RANDOM_ALGS_AND_PARAMS
  }

  /**
    * Determines how immigrating individuals are handled.
    *
    * @param met One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
    */
  def setImmigrationMethod(met: SiPDEPopulation.acceptImmigrantsMethod) {
    immigrationMethod = met
  }

  /**
    * Determines how emigrating individuals are chosen.
    *
    * @param met One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
    */
  def setEmigrationMethod(met: SiPDEPopulation.expelEmigrantsMethod) {
    emigrationMethod = met
  }

  /**
    * If verbose setting is set to true, all populations with all their individuals will be written to Logger
    *
    * @param verb true/false
    */
  def setVerbose(verb: Boolean) {
    VERBOSE = verb
  }
  /**
    *@param index 岛的编号
    * @param alg Population specific algorith
    * @param subpopParameters Map collection of parameters for given algorithm
    */
  def addSubpopulationsConfig(index:Int,alg:Class[_ <: Algorithm], subpopParameters:JHashMap[String, Double]) {
    addSubpopulationsConfig(index,alg, defaultPopSize, subpopParameters);
  }
  //addSubpopulationsConfig :Class[_ <: Algorithm]
  def addSubpopulationsConfig(index:Int,alg: Class[_ <: Algorithm], popSize:Int, subpopParameters:JHashMap[String, Double]){
    //将数据进行存储
    //将参数F、CR存放在相应的岛中
    configDouble.add(index,subpopParameters)
    //System.out.println("configDouble.get(0).apply(\"F\")"+configDouble.get(0).get("F"))
    //alg.newInstance().asInstanceOf[Algorithm]
    //存放优化器
    //configClass.put("algorithm_"+index,alg.toString)
    //System.out.println("====="+alg)
    //index=0,alg.newInstance().asInstanceOf[Algorithm]=CUDE
    configAlg.put(index,alg.newInstance().asInstanceOf[Algorithm])
    //种群大小
    configClass.put(index,popSize)

  }
}
/*
class MakeFoo[A](implicit manifest: Manifest[A]) {
    def make: A = manifest.erasure.newInstance.asInstanceOf[A]
}*/

