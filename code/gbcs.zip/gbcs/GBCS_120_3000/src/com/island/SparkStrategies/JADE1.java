package com.island.SparkStrategies;

//import cec2010.Function;
import CEC2013.Function;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.java.tools.RandSet;

/**
 *
 * @author mouse
 */
public class JADE1 extends Algorithm {
    static protected double F = 0.1;
    static protected double CR = 0.1;

    static protected double p; //percento najlepsich pre krizenie
    static protected int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    static protected double uF, uCR, c;
    static protected double SF, SF2; //sucet a mocnina uspesnych F hodnot
    double SCR, nSCR; //sucet a pocet uspesnych CR hodnot
    static protected Random rng;
    int generations;

    public JADE1(){

    }
    public JADE1(Function f, int D_, int popSize_) {
        //super(f, D_, popSize_);

        dimensions = D_;
        popSize = popSize_;
        function = f;
        population.setFitnessFunction(f);
        minPopulationSize = 5;

        uCR = 0.5; SCR = 0; nSCR = 0;
        uF = 0.6; SF = 0; SF2 = 0;
        c = 0.1;
        p = 0.2; //20%
        numP = (int)Math.round(((double)popSize) * p);

        rng = new Random( System.currentTimeMillis());
    }
    public JADE1(Function f, int D_, int popSize_, int generationsPerRound) {
        this(f,D_,popSize_);
        this.generations=generationsPerRound;
    }

    //DE/current-to-p-best
    @Override
    public SiPDEIndividuals generation()throws Exception {
        try {
            if (popSize < minPopulationSize) {
                throw new Exception("popSize can't be smaller than " + minPopulationSize + ".");
            }
        } catch (Exception ex) {
            //Logger.getLogger(DERand1bin.class.getName()).log(Level.SEVERE, null, ex);
        }

        population.computeFandCR();
        SCR = 0; nSCR = 0;
        SF = 0; SF2 = 0;

        SiPDEIndividuals rand1, rand2, rand3, bi;

        RealVector noisy;
        RealVector trial;
        double[] active;
        int rand1Index = 0;
        int rand2Index = 0;
        int rand3Index = 0;
        int biIndex = 0;
        double trialFitness, activeFitness;

        int iter=0;
        //CUDE的变异迭代策略
        while (iter<940 ) {//generations
            iter = iter + 1;
            for (int ind = 0; ind < popSize; ind++) {
                trial = new ArrayRealVector(dimensions); //new double[dimensions];
                noisy = new ArrayRealVector(dimensions);//new double[dimensions];


                active = population.get(ind).getGeno().toArray();
                activeFitness = population.get(ind).getFitness();
                F = population.getF(ind);
                CR = population.getCR(ind);

                //第二种
                do {
                     biIndex = rng.nextInt(numP);
                    biIndex = population.getIndexFromFitnessOrder(biIndex); //之前与population
                } while (biIndex == ind);
                bi = population.get(biIndex);
                //System.out.println(biIndex);

                do {
                    rand1Index = (rng.nextInt(popSize));
                } while (rand1Index == biIndex || rand1Index == ind);
                rand1 = population.get(rand2Index);

                do {
                    rand2Index = (rng.nextInt(popSize));
                } while (rand2Index == ind || rand2Index == biIndex || rand2Index == rand1Index);
                rand2 = population.get(rand2Index);

                for (int j = 0; j < dimensions; j++) {
                    double pom = active[j] + F * (bi.getGene(j) - active[j]) + F * (rand1.getGene(j) - rand2.getGene(j));
                    //double pom = (rand1.getGene(j) - rand2.getGene(j)) * F + rand3.getGene(j);

                    if (pom < function.getMin() || pom > function.getMax()) {
                        pom = function.getRandomValueInDomains(j);
                        pom = function.getMin() + (Math.random() * ((function.getMax() - function.getMin()) + 1)); //function.getRandomValueInDomains(j);
                    }

                    noisy.addToEntry(j, pom);
                    trial.addToEntry(j, (Math.random() < CR) ? noisy.getEntry(j) : active[j]);
                }

                trialFitness = function.compute(trial.toArray());
                // Replace if trial is better
                if (trialFitness < activeFitness) {
                    SiPDEIndividuals indiv = new SiPDEIndividuals(population, trial);
                    indiv.setFitness(trialFitness);
                    population.set(ind, indiv);
                    SCR += CR;
                    nSCR++;
                    SF += F;
                    SF2 += F * F;
                }
                if (population.get(ind).getFitness() < bestFitness) {
                    bestIndividual = population.get(ind);
                    bestFitness = bestIndividual.getFitness();
                }
            }
            population.updateuCR(SCR, nSCR);
            population.updateuF(SF, SF2);
        }

            bestFitness=population.getBestIndividual().getFitness();
            bestIndividual = population.getBestIndividual();
            return bestIndividual;
    }

    public SubPopulation generationCC(HashMap<Integer, RealVector> pop, RealVector bestind, double bestvalue, List<Integer> subscript, int itermax, ArrayList tracerst) throws IOException {
        return null;
    }

    @Override
    public SiPDEPopulation getPopulation() {
        // TODO Auto-generated method stub
        return population;
    }

    @Override
    public void newRound() {
        // TODO Auto-generated method stub

    }

    public void setParameter(String configName, double value) {
        // TODO Auto-generated method stub
        if (configName.equals("F")) {
            F = value;
        } else if (configName.equals("CR")) {
            CR = value;
        }
    }
}
