package com.island.SparkStrategies;

//import cec2010.Function;
//import cer2003.FitnessFunction;
import CEC2013.Function;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

import java.io.Serializable;
import java.util.*;

/**
 * Created by hadoop on 16-11-10.
 */
public class SiPDEPopulation implements Serializable {
    protected Function function;
    public int dimensions;
    protected ArrayList<SiPDEIndividuals> individualsList = new ArrayList();
    protected RealMatrix pop;
    protected SiPDEIndividuals bestIndividual = null;
    protected boolean sorted = false;
    protected boolean migrationFlag;
    protected int key; //population key
    Random rng;
    protected double[] Fs; //F for every individual
    protected double[] CRs; //CR for every individual
    protected int index = Integer.MAX_VALUE;

    double p; //percento najlepsich pre krizenie
    int numP; //pocet najlepsich pre krizenie, vychadza z hodnoty p
    double uF, uCR, c;

    protected static int m=0;
    //protected static ArrayList<Integer> tmpp=new ArrayList<Integer>(); //15为迁移个体的长度
    /**
     * Determines how immigrating individuals are handled.
     */
    public static enum acceptImmigrantsMethod {
        /**Replace individuals with worst value*/
        REPLACE_WORST,
        /**Replace individuals with best value*/
        REPLACE_BEST,
        /** Replace random individuals*/
        REPLACE_RANDOM,
        /*Adds immigrants to population by increasing its size        */
        NO_REPLACE
    }
    /**
     * Determines how emigrating individuals are chosen.
     */
    public static enum expelEmigrantsMethod {
        /**Migrate best individuals */
        EXPEL_BEST,
        /**Migrate random individuals  */
        EXPEL_RANDOM,
        /**Migrate 1 best individual and some random individuals         */
        EXPEL_BEST_AND_RANDOM,
    }
    //初始化个体集容器
    void initializeJADEConstants() {
        uCR = 0.5;
        uF = 0.6;
        c = 0.1;
        p = 0.2; //20%
        numP = (int) Math.round(((double)individualsList.size()) * p);
        rng = new Random(System.currentTimeMillis());
    }
    /**
     * Constructs Population with given Individuals
     *
     * @param population ArrayList of Individuals who will become the new Population
     */
    public SiPDEPopulation(ArrayList<SiPDEIndividuals> population) {
        individualsList = population;
        migrationFlag = false;
        initializeJADEConstants();
    }

    /**
     *  Parameterless constructor
     */
    public SiPDEPopulation() {
        migrationFlag = false;
        initializeJADEConstants();
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return lower restriction of given dimension
     */
    public double getMinRestriction(int i) {
        return function.getMin();
    }

    /**
     *
     * @param i Dimension from which the restriction is returned
     * @return upper restriction of given dimension
     */
    public double getMaxRestriction(int i) {
        return function.getMax();//.getMaxRestriction(i);
    }
    public double getuCR() {
        return uCR;
    }

    public double getuF() {
        return uF;
    }

    /**
     *
     * @param j Index of Individual to return
     * @return Individual with index j
     */
    public SiPDEIndividuals get(int j) {
        return individualsList.get(j);
    }


    /**
     * Sets one Individual with index j, rewriting the old one
     *
     * @param j Index of new Individual
     * @param ind Individual to be added
     */
    public void set(int j, SiPDEIndividuals ind) {
        individualsList.set(j, ind);
        sorted = false;
    }

    /**
     * Makes new Population from Individuals given in the individuals parameter
     *
     * @param individuals ArrayList of new Individuals
     */
    public void setPopulation(ArrayList<SiPDEIndividuals> individuals) {
        individualsList = individuals;
        sorted = false;
        sort();
    }
    /**
     * Set Individuals population to this Population. Needed after adding external Individuals.
     */
    //所有要替换的个体重新赋值下标，0-14
    public void resetIndividualsPopulation(){
        for(SiPDEIndividuals ind : individualsList)
            ind.setPopulation(this);
    }
    /**
     *
     * @return ArrayList of Individuals from Population
     */
    public ArrayList<SiPDEIndividuals> getPopulation() {
        return individualsList;
    }

    ////////////////////2017-07-23
    /*
     * 获取该种群中的维度为dim的子个体
     * RealVector List<Double>
     */
    public HashMap<Integer, RealVector>  getPopulation(List<Integer> dim) {
        HashMap<Integer, RealVector> subindividual=new HashMap<>();
        for(int i=0;i<individualsList.size();i++){
            RealVector ind = new ArrayRealVector(dim.size());
            for (int j = 0; j < dim.size(); j++) {
                ind.addToEntry(j,individualsList.get(i).getGene(dim.get(j)));
            }
            subindividual.put(i,ind);
        }
        return subindividual;
    }
    /*
     * 获取该种群中的维度为dim的子个体
     * RealVector List<Double>
     *     ArrayList<SiPDEIndividuals> individualsList
     */
    public void setPopulation(HashMap<Integer, RealVector> subpop,List<Integer> dim) {
        //HashMap<Integer, RealVector> subindividual=new HashMap<>();
        for(int i=0;i<individualsList.size();i++){
            for (int j = 0; j < dim.size(); j++) {
                individualsList.get(i).setGene(dim.get(j), subpop.get(i).getEntry(j));
            }
        }
    }
    /**
     * Sets fitness function of this Population which is later used to create Individuals and determine their fitness
     * @param ff FitnessFunction extending class
     */
    public void setFitnessFunction(Function ff) {
        function = ff;
    }


    /**
     * @return population size
     */
    public int size() {
        return individualsList.size();
    }

    public void updateuCR(double SCR, double nSCR)
    {
        if(nSCR != 0) {
            uCR = (1 - c)*uCR + c*(SCR / nSCR);
        }
    }

    public void updateuF(double SF, double SF2)
    {
        if(SF != 0) {
            uF = (1 - c)*uF + c*(SF2 / SF);
        }
    }

    /**
     * Ads one Individual to population
     *.collect()
     * @param ind Individual to add
     */
    public void add(SiPDEIndividuals ind) {
        individualsList.add(ind);
        sorted = false;
    }

    /**
     * Ads one random Individual to population
     */
    public void addRandomIndividual(int d) throws Exception{
        if(function != null) {
            double min, max;
            RealVector values = new ArrayRealVector(d);
            for (int k = 0; k < d; k++) {
                min = function.getMin();//.getMinRestriction(k);
                max = function.getMax();//.getMaxRestriction(k);
                //  Get random double within range.
                values.addToEntry(k, min + (Math.random() * ((max - min) + 1)));
                //System.out.println("values="+values.getEntry(k));
            }
            SiPDEIndividuals ind = new SiPDEIndividuals(this,values);

            //ind.setIndex();
            ind.setFitness(function.compute(values.toArray()));
            add(ind);
            sorted = false;
        }
    }
    /**
     * Ads one random Individual to population
     */
    //n=20 ,d =1000
    public void addRandomIndividual(int n,int d) throws Exception{
        if(function != null) {
            double min, max;
            RealVector values = new ArrayRealVector(d);
            for (int k = 0; k < d; k++) {
                //获取每个函数的取值范围
                min = function.getMin();//.getMinRestriction(k);
                max = function.getMax();//.getMaxRestriction(k);
                //  Get random double within range. 随机生成范围内的个体每个维度值
                values.addToEntry(k, min + (Math.random() * ((max - min) + 1)));
                //System.out.println("values="+values.getEntry(k));
            }
            SiPDEIndividuals ind = new SiPDEIndividuals(this,values,n);
            //ind.setLine(n);//设置该个体的行号
            //System.out.println("初始化的Index="+ind.getIndex()+";;;;Line="+ind.getLine());
            //ind.setIndex();
            ind.setFitness(function.compute(values.toArray()));
            add(ind);
            sorted = false;
        }
    }

    /**
     * Ads a number of random Individuals to population
     *
     * @param n number of Individuals to add
     */
    //n=20,d=1000
    public void addRandomIndividuals(int n, int d) throws Exception{
        for(int i = 0; i< n; i++) {
            addRandomIndividual(i,d);
        }
    }
    /**
     * Removes one Individual from Population with given index i
     *
     * @param i Index of removed Individual
     */
    public void drop(int i) {
        individualsList.remove(i);
    }

    /**
     * Clears Population by removing all Individuals
     */
    public void clear() {
        individualsList.clear();
        sorted = false;
    }


    protected double nextGaussian(double mean, double variance) {
        return rng.nextGaussian()*Math.sqrt(variance)+mean;
    }

    public void computeFandCR() {
        Fs = new double[individualsList.size()];
        CRs = new double[individualsList.size()];

        for(int i = 0; i < individualsList.size(); i++)
        {
            CRs[i] = nextGaussian(uCR, 0.1); //initiate CRs...
        }

        double rndProb = 0.34;
        for(int i = 0; i < individualsList.size(); i++) //toto bolo inak...
        {
            if(rng.nextDouble() < rndProb)
                Fs[i] = nextGaussian(uF, 0.1);
            else
                Fs[i] = rng.nextDouble() * 1.2;
        }
    }

    public double getF(int index) {
        return Fs[index];
    }

    public double getCR(int index) {
        return CRs[index];
    }

    /**
     * Sets all Individuals to random values
     */
    public void randomize() throws Exception{
        for (SiPDEIndividuals ind : individualsList) {
            ind.randomize();
            evaluateIndividual(ind);
        }
    }
    /**
     * @param i Individual to be evalueated
     * @return fitness of the Individual
     */
    public double evaluateIndividual(SiPDEIndividuals i) throws Exception{
        double fit = function.compute(i.getGeno().toArray());
        i.setFitness(fit);
        return fit;
    }

    /**
     * @param all Individual to be evalueated
     * @return fitness of the Individual
     */
    public void evaluateAllIndividual() throws Exception{
        for(int i=0;i<individualsList.size();i++) {
            double fit = function.compute(individualsList.get(i).getGeno().toArray());
            this.individualsList.get(i).setFitness(fit);
        }
        //return fit;
    }

    //新增
    public int getIndex() {
        return index;
    }

    /**
     * Get population index of the best Individual
     * @return
     */
    //获取最优个体的索引
    public int getBestIndex() {
        int min_n = 0;
         double min = Double.POSITIVE_INFINITY;
        //?
        for (int j = 0; j < individualsList.size(); j++) {
            if (individualsList.get(j) != null && individualsList.get(j).getFitness() < min) {
                min = individualsList.get(j).getFitness();
                min_n = j;
            }
        }
        return min_n;
    }
    /**
     * Get Individual by his population index
     * @param i Order of the Individual by fitness
     * @return Index of Individual
     */
    public int getIndexFromFitnessOrder(int i) {
        //System.out.println("sort"+sorted);
        if(!sorted) {
            sort();
        }
        int n = 0;
        ArrayList<Integer> tmpp=new ArrayList<Integer>(); //15为迁移个体的长度
        //System.out.println("individualsList.size()"+individualsList.size());
        for (SiPDEIndividuals ind : individualsList) {
            //System.out.println("for循环内n="+n+"individualsList.size()"+individualsList.size()+";ind.getIndex()="+ind.getIndex()+";i="+i);
             if (ind.getIndex() == i) {
                 tmpp.add(n);  //创建一个可变数组长度的临时变量存放每一次的n值
                return n;
            }
            n++;
        }
        //改动的，原来没有返回-1,没有找到适应度值则返回最好的一个适应度值
        //return -1;
        m++;
        //int j=tmpp.get(0);
        Random rd= new Random();
        int j = rd.nextInt(20);
        //System.out.println("i是:"+i+"大小："+individualsList.size()+"index是"+n+"m是"+m);
        return j;
    }

    public int getIndexFromFitnessOrder2(int i) {
        //System.out.println("sort"+sorted);
        if(!sorted) {
            sort();
        }
        int n = 0;
        //System.out.println("individualsList.size()"+individualsList.size());
        for (SiPDEIndividuals ind : individualsList) {
            //System.out.println("for循环内n="+n+"individualsList.size()"+individualsList.size()+";ind.getIndex()="+ind.getIndex()+";i="+i);
            if (ind.getIndex() == i) {
                return n;
            }
            n++;
        }
        System.out.println("i是:"+i+"大小："+individualsList.size()+"index是"+n);
        return -1;
    }


    /**
     *
     * @return best individual of existing population.
     */
    public SiPDEIndividuals getBestIndividual() {
        if (sorted && bestIndividual != null) {
            return bestIndividual;
        } else {
            return individualsList.get(getBestIndex());
        }
    }
    @Override
    public SiPDEPopulation clone() {
        return new SiPDEPopulation(individualsList);
    }

    public Iterator<SiPDEIndividuals> iterator() {
        return individualsList.iterator();
    }

    public int compareTo(SiPDEPopulation o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    /**
     * Each population has its unique key given by the framework at initialization by this function.
     *
     * @param k integer to set the key to.
     */
    public void setKey(int k) {
        key = k;
    }

    /**
     * @return the key (id) of the population
     */
    public int getKey() {
        return key;
    }

    @Override
    public String toString() {
        String str = "";
        str += "Population key: " + key + "\n";
        str += "Size: "+size() + "\n";
        str += "Best fitness: " + getBestIndividual().getFitness() + "\n";

        str += "uF: " + uF + "\n";
        str += "uCR: " + uCR + "\n";

        for (int i = 0; i < individualsList.size(); i++) {
            str += "\n\rIndividual " + i + " : " + individualsList.get(i).toString();
            //str += ", F: " + getF(i);
            //str += ", CR: " + getCR(i);
        }

        return str;
    }

    /**
     *  Sorts the population by fitness
     */
    public void sort() {
        double tmp[][] = new double[individualsList.size()][2];
        for (int i = 0; i < individualsList.size(); i++) {
            tmp[i][0] = individualsList.get(i).getFitness();
            tmp[i][1] = i;
        }
        Arrays.sort(tmp, new IndividualListFitnessComparator());
        for (int i = 0; i < tmp.length; i++) {
            int ind = (int)(tmp[i][1]);
            individualsList.get(ind).setIndex(i);
        }
        sorted = true;
    }
    protected class IndividualListFitnessComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            double f1 = ((double[])o1)[0];
            double f2 = ((double[])o2)[0];
            if (f1 > f2) {
                return 1;
            } else if (f1 < f2) {
                return -1;
            } else {
                return 0;
            }
        }
    }


    public void send(){

    }

    /**
     * Accepts immigrants into existing population.
     * 替换的策略
     * @see acceptImmigrantsMethod
     * @param immigrants Immigrating Population
     * @param method One of Population.acceptImmigrantsMethod (REPLACE_WORST, REPLACE_BEST, REPLACE_RANDOM, NO_REPLACE).
     */
    //替换策略
    public void acceptImmigrants(SiPDEPopulation immigrants, acceptImmigrantsMethod method) {
        //System.out.println("immigrantsmethod=="+method);
        switch (method) {
            case REPLACE_WORST://选择要迁移的个体，15个最好的,运行五次，五个岛，存入了rdd中
                if (!sorted) {
                    sort();
                }
                for (int i = 0, j = individualsList.size() - 1, n = -1; i < immigrants.size(); i++, j--) {
                    n = getIndexFromFitnessOrder(j);//获取要迁移个体的下标,通过适应度值来获取个体下标
                    if (n != -1) {
                        individualsList.set(n, immigrants.get(i));
                    }
                }
                break;
            case REPLACE_BEST:

                if (!sorted) {
                    sort();
                }

                for (int i = 0, n = -1; i < immigrants.size() && i < individualsList.size(); i++) {
                    n = getIndexFromFitnessOrder(i);
                    individualsList.set(n, immigrants.get(i));
                }
                break;
            case REPLACE_RANDOM:
                Double r = 0.0;
                for (int i = 0; i < immigrants.size(); i++) {
                    r = Math.random() * individualsList.size();
                    individualsList.set(r.intValue(), immigrants.get(i));
                }
                break;
            case NO_REPLACE:
                for (int i = 0; i < immigrants.size(); i++) {
                    individualsList.add(immigrants.get(i));
                }
                break;
        }

        sorted = false;
    }

    /**
     * Expels immigrants from evolved population.
     * 提出的种群
     * @see expelEmigrantsMethod
     * @param nMigratingIndividuals Number of emigrants
     * @param method One of Population.expelEmigrantsMethod (EXPEL_BEST, EXPEL_RANDOM).
     */
    public SiPDEPopulation getEmigrants(int nMigratingIndividuals, expelEmigrantsMethod method) {
        SiPDEPopulation temp = new SiPDEPopulation();
        int index;
        //System.out.println("Emigrantsmethod=="+method+";;nMigratingIndividuals="+nMigratingIndividuals);
        switch (method) {
            case EXPEL_BEST: {
                //将要迁移的个体放入临时变量temp中
                for (int i = 0; i < nMigratingIndividuals; i++) {
                    //System.out.println(i);//新加
                    index = getIndexFromFitnessOrder(i);
                    temp.add(individualsList.get(index));

                    /*//修改
                    individualsList.
                    //index = getIndexFromFitnessOrder(i);
                    temp.add(individualsList.get(i));
                    //System.out.println(temp.size());*/
                }
                break;
            }
            case EXPEL_RANDOM: {
                Double r = 0.0;

                for (int i = 0; i < nMigratingIndividuals; i++) {
                    r = Math.random() * individualsList.size();
                    index = getIndexFromFitnessOrder(r.intValue());
                    temp.add(individualsList.get(index));
                }
                break;
            }
            case EXPEL_BEST_AND_RANDOM: {
                index = getIndexFromFitnessOrder(0);
                temp.add(individualsList.get(index)); //add best
                //System.out.println("index=="+index);
                Double r = 0.0;
                for (int i = 0; i < nMigratingIndividuals; i++) {
                    r = Math.random() * individualsList.size();
                    //System.out.println("查找index；r==" + r + ";r.intValue()=" + r.intValue() + ";");
                    index = getIndexFromFitnessOrder(r.intValue());
                    //System.out.println("r==" + r + ";r.intValue()=" + r.intValue() + ";index==" + index);
                    /*if (index==-1){
                        index=r.intValue();
                    }*/
                    temp.add(individualsList.get(index)); //add random
                }
                break;
            }
        }

        return temp;
    }
    //n为行
    public RealVector addCCRandomIndividuals(int row, int d) throws Exception{
        //System.out.println("==d=="+d+"==n=="+n);
        RealVector values = new ArrayRealVector(d + 1);
        if(function != null) {
            double min, max;
            //RealVector
            for (int k = 0; k < d; k++) {
                min = function.getMin();//.getMinRestriction(k);
                max = function.getMax();//.getMaxRestriction(k);
                //  Get random double within range.
                values.setEntry(k, min + (Math.random() * (max - min)));
            }
            double fit = function.compute(values.toArray());
            values.setEntry(d, fit);
        }
        return values;
    }
}
