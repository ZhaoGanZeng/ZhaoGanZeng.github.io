package com.island.SparkStrategies;

/**
 * 
 * @author txj
 */

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Random;

public class Topologies implements Serializable {

    /**
     * Ring拓扑结构：
     * 比如有3个岛。0-->1-->2-->0
     */
    public static class Ring extends Topology {

        /**
         * 
         * @param islands
         */
        public Ring(int islands) {
            super(islands);
        }

        /**
         * 
         * @param n
         * @return
         */
        //环形topo
        @Override
        public int[] get(int n) {
            int[] arr = {(n + 1) % (islandsNumber/3)};
            return arr;
        }

        //星型topo
        @Override
        public int[] get_xing(int n){
            int[] arr = {islandsNumber/3-1};  //arr_islandCount=3
            return arr;
        }

        //网状topo
        @Override
        public int[] get_wang(int n) {
            int[] arr=new int[islandsNumber/3];
            for(int i=0;i<(islandsNumber/3);i++){
                arr[i] = (n + i) % (islandsNumber/3);
            }
            //int[] arr = {(n + 1) % islandsNumber, (n + 2) % islandsNumber};
            return arr;
        }

        /**
         *
         * @param n
         * @return
         */
        @Override
        public int[] getImmigration(int n) {
            int r=islandsNumber-1;
            if (n!=0){//岛的编号从0开始的
                r = n-1;
            }
            int[] arr = {r};
            return arr;
        }
    }

    /**
     * 
     */
    public static class Ring_1_2 extends Topology {

        /**
         * Ring_1_2拓扑结构
         * 比如有3个岛：
         * 0-->2
         * 0-->1
         *
         * 1-->2
         * 1-->0
         *
         * 2-->0
         * 2-->1
         * @param islands
         */
        public Ring_1_2(int islands) {
            super(islands);
        }

        /**
         * 
         * @param n
         * @return
         */
        @Override
        public int[] get(int n) {
            int[] arr = {(n + 1) % islandsNumber, (n + 2) % islandsNumber};
            return arr;
        }

        //星型topo
        @Override
        public int[] get_xing(int n){
            int[] arr = {islandsNumber-1};
            return arr;
        }

        //网状topo
        @Override
        public int[] get_wang(int n) {
            int[] arr=new int[islandsNumber];
            for(int i=0;i<islandsNumber;i++){
                arr[i] = (n + i) % islandsNumber;
            }
            //int[] arr = {(n + 1) % islandsNumber, (n + 2) % islandsNumber};
            return arr;
        }

        /**
         *?需要修改
         * @param n
         * @return
         */
        @Override
        public int[] getImmigration(int n) {
            int[] arr = {(n + 1) % islandsNumber};
            return arr;
        }
    }

    /**
     * 
     */
    public static class RandomT extends Topology {
        Random rng;
        /**
         * 根据当前岛的编号随机选择另一个岛
         * @param islands
         */
        public RandomT(int islands) {
            super(islands);
            rng = new Random(System.currentTimeMillis());
        }

        /**
         * 
         * @param n
         * @return
         */
        @Override
        public int[] get(int n) {
            int r;
            do {
                r = rng.nextInt(islandsNumber);
            } while(r == n);

            int[] arr = {r};

            return arr;
        }

        //星型topo
        @Override
        public int[] get_xing(int n){
            int[] arr = {islandsNumber-1};
            return arr;
        }

        //网状topo
        @Override
        public int[] get_wang(int n) {
            int[] arr=new int[islandsNumber];
            for(int i=0;i<islandsNumber;i++){
                arr[i] = (n + i) % islandsNumber;
            }
            //int[] arr = {(n + 1) % islandsNumber, (n + 2) % islandsNumber};
            return arr;
        }

        /**
         *
         * @param n
         * @return
         */
        @Override
        public int[] getImmigration(int n) {
            int r;
            do {
                r = rng.nextInt(islandsNumber);
            } while(r == n);

            int[] arr = {r};

            return arr;
        }
    }

    /**
     * Emits individuals into random number of random subpopulations.
     */
    public static class MultiRandom extends RandomT {

        /**
         *
         * @param islands
         */
        public MultiRandom(int islands) {
            super(islands);
        }

        /**
         *
         * @param n
         * @return
         */
        @Override
        public int[] get(int n) {
            int nReceivingIslands = rng.nextInt(islandsNumber/2);
            int r;

            LinkedList<Integer> arr = new LinkedList<Integer>();

            for(int i = 0; i<nReceivingIslands; i++) {
                do {
                    r = rng.nextInt(islandsNumber);
                } while(r == n || arr.contains(r));
                arr.add(r);
            }
            int[] intAr = new int[arr.size()];
            for(int i = 0; i <arr.size(); i++) {
                intAr[i] = arr.pop();
            }
            return intAr;
        }
    }

    /**
     * 
     */
    public static class Const1 extends Topology {

        /**
         * 
         * @param islands
         */
        public Const1(int islands) {
            super(islands);
        }

        /**
         * 
         * @param n
         * @return
         */
        @Override
        public int[] get(int n) {
            int[] arr = {1};
            return arr;
        }

        //星型topo
        @Override
        public int[] get_xing(int n){
            int[] arr = {islandsNumber-1};
            return arr;
        }

        //网状topo
        @Override
        public int[] get_wang(int n) {
            int[] arr=new int[islandsNumber];
            for(int i=0;i<islandsNumber;i++){
                arr[i] = (n + i) % islandsNumber;
            }
            //int[] arr = {(n + 1) % islandsNumber, (n + 2) % islandsNumber};
            return arr;
        }

        /**
         *
         * @param n
         * @return
         */
        @Override
        public int[] getImmigration(int n) {
            int[] arr = {1};
            return arr;
        }
    }
}
