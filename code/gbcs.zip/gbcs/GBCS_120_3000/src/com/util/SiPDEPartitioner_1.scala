package com.util

import com.island.SparkStrategies.{SiPDEPopulation, Topology}
import org.apache.spark.{Partitioner, HashPartitioner}
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.receiver.IteratorBlock

/**
  * Created by hadoop on 16-11-15.
  */
//rdd:RDD[(Int, SiPDEPopulation)收集的数据对应emigrants的(r._1,emig)，int对应r._1，SiPDEPopulation对应emig
/*class SiPDEPartitioner (rdd:RDD[(Array[(Int,SiPDEPopulation)],Int)],topology:Topology,arr_islandcount:Int,numParts: Int,acceptImmigrants:SiPDEPopulation.acceptImmigrantsMethod) extends Partitioner{
  override def numPartitions: Int = arr_islandcount
  //覆盖分区号获取函数
  //获取每个分区中的数据  val rd:Array[(Int, SiPDEPopulation)]=rdd.collect() Array[(Int, SiPDEPopulation)]
  val rd:Array[(Array[(Int, SiPDEPopulation)],Int)]=rdd.collect() //按F8 Array[(Array[(Int, SiPDEPopulation)],Int)]
 /* val rd2 =rd.map(r=>{
    val pop=r._1(2)
    pop
  })
  rd2*/
  val num:Int= arr_islandcount//numParts
  def getFit():Double={
    /*val population:Array[Double]=rdd.map(x=>{
      x._2.get(0).getFitness
    }).collect()
    //System.out.println("第一个岛的适应度值"+population.get(0).getFitness)
    population.apply(0)*/
    0
  }*/
class SiPDEPartitioner_1 (rdd:RDD[(Int,Array[(Int,SiPDEPopulation)])],topology:Topology,arr_islandcount:Int,numParts: Int,acceptImmigrants:SiPDEPopulation.acceptImmigrantsMethod) extends Partitioner{
  override def numPartitions: Int = arr_islandcount//numParts
  //覆盖分区号获取函数
  //获取每个分区中的数据  val rd:Array[(Int, SiPDEPopulation)]=rdd.collect() Array[(Int, SiPDEPopulation)]
  val rd:Array[(Int,Array[(Int, SiPDEPopulation)])]=rdd.collect() //按F8 Array[(Array[(Int, SiPDEPopulation)],Int)]
   /*val rd2 =rd.map(r=>{
     val pop=r._2
     pop
   })*/
  //val rd2=rd(2)
  val num:Int= arr_islandcount//numParts
  def getFit():Double={
    /*val population:Array[Double]=rdd.map(x=>{
      x._2.get(0).getFitness
    }).collect()
    //System.out.println("第一个岛的适应度值"+population.get(0).getFitness)
    population.apply(0)*/
    0
  }

  override def getPartition(key: Any): Int = {
      var population:Array[(Int,SiPDEPopulation)]=key.asInstanceOf[Array[(Int,SiPDEPopulation)]]//SiPDEPopulation=key.asInstanceOf[SiPDEPopulation]
      //val population2:SiPDEPopulation=key.asInstanceOf[SiPDEPopulation]
    //System.out.println("第"+population.getKey+"个岛的适应度值"+population.getBestIndividual.getFitness)

    //System.out.println("rd"+rd.length)



    //var k = population.getPopulation.get(population.getKey).getFitness
    //获取第population.getKey个岛中的第一行的编号
    //for(r<-0 to 5){
    //population(1)._1
    /*var i=0
        var popu=population
        var k1=popu.map(r=>{
        var pop=r._2
        var k =r._1
        var migratingkey=topology.get(k)//该岛所对应的迁移的岛
        population(2)._2.resetIndividualsPopulation();
        for(i<-0 to  migratingkey.length-1){ //rd(1)._1.apply(migratingkey.apply(i))._2
          //rd2(2).apply(migratingkey.apply(i))._2,acceptImmigrants
          pop.acceptImmigrants(population.apply(migratingkey.apply(i))._2,acceptImmigrants)
          //population.acceptImmigrants(rd.apply(migratingkey.apply(i))._2,acceptImmigrants)
        }
          var n=i
          n
      })
      i=i+1
      val m=k1(1)
    m
*/

    //var i=0
    //var popu=population
    //var k1=popu.map(r=>{
    /*var pop:SiPDEPopulation=null
    var migratingkey:Array[Int]=Array(0)
    //var m:Int=0
    //第一个for进行分组的岛内的信息交互
    for(r<-0 to 4){   //population(2)
      //pop=population(r)._2 //rd2._2(2)._2//population(2)._2
      var k=r//population(r)._2.getKey//r._1   ??????
      if(k==4){
        k=0
        migratingkey=Array(0)
      }else {
        migratingkey = topology.get(k)
      }
      //var migratingkey=topology.get(k)//该岛所对应的迁移的岛
      population(r)._2.resetIndividualsPopulation();
      for(i<-0 to  migratingkey.length-1){ //rd(1)._1.apply(migratingkey.apply(i))._2
        //rd2(2).apply(migratingkey.apply(i))._2,acceptImmigrants
        //分组内的信息交换
        population(r)._2.acceptImmigrants(population.apply(migratingkey.apply(i))._2,acceptImmigrants)
        //population.acceptImmigrants(rd.apply(migratingkey.apply(i))._2,acceptImmigrants)

        //分组间的信息交换
        var m=population(i)._2.getKey+1
        if(m==3){
          m=0
        }
        population(r)._2.acceptImmigrants(rd(m)._2.apply(migratingkey.apply(i))._2,acceptImmigrants)

      }
      /*var n=i
      n
      //})
      i=i+1
     // val m=0 //k1(1)*/
    }*/

    var migratingkey:Array[Int]=Array(0)
    //for (r<-0 to 2){
    for (i<-0 to 4){
      var k1 = i //rd(2)._2(r)._2.getKey  //获取每个分组的key
      /*if(k==4){
        k=0
        migratingkey=Array(0)
      }else {
        migratingkey = topology.get(k)
      }*/
      migratingkey = topology.get(k1)
      population(i)._2.resetIndividualsPopulation();
      for(n<-0 to  migratingkey.length-1){ //rd(1)._1.apply(migratingkey.apply(i))._2   rd(k)._2

        //rd.apply(migratingkey.apply(i))._2,acceptImmigrants;population.apply(migratingkey.apply(n))._2,acceptImmigrants


        var m=population(i)._2.getKey+1
        if(m==3){
          m=0
        }
        var h= population(i)._2.getKey
        population(i)._2.acceptImmigrants(rd(h)._2.apply(migratingkey.apply(n))._2,acceptImmigrants)
        population(i)._2.acceptImmigrants(rd(m)._2.apply(migratingkey.apply(n))._2,acceptImmigrants)
        //population.acceptImmigrants(rd.apply(migratingkey.apply(i))._2,acceptImmigrants)
      }
    }

    //第二个for进行分组间的信息交互
    /*for (i<-0 to 4){
      var k = i //rd(2)._2(r)._2.getKey  //获取每个分组的key
      if(k==4){
        k=0
        migratingkey=Array(0)
      }else {
        migratingkey = topology.get(k)
      }
      population(i)._2.resetIndividualsPopulation();
      for(n<-0 to  migratingkey.length-1){ //rd(1)._1.apply(migratingkey.apply(i))._2   rd(k)._2
        var m=population(i)._2.getKey+1
        if(m==3){
          m=0
        }
        population(i)._2.acceptImmigrants(rd(m)._2.apply(migratingkey.apply(n))._2,acceptImmigrants)
        //population.acceptImmigrants(rd.apply(migratingkey.apply(i))._2,acceptImmigrants)
      }
    }*/
    var k =population(2)._2.getKey
    k.toInt%numPartitions
    /*m=population(2)._2.getKey
    m.toInt%numPartitions//???没运行*/
  }

  /*var k:Int=0
  for(r<-0 to 5){   //population(2)
    val pop=population(2)._2 //rd2._2(2)._2//population(2)._2
    k=r//population(2)._2.getKey//r._1   ??????
    val migratingkey=topology.get(k)//该岛所对应的迁移的岛
    population(2)._2.resetIndividualsPopulation();
    for(i<-0 to  migratingkey.length-1){ //rd(1)._1.apply(migratingkey.apply(i))._2
      //rd2(2).apply(migratingkey.apply(i))._2,acceptImmigrants
      pop.acceptImmigrants(population.apply(migratingkey.apply(i))._2,acceptImmigrants)
      //population.acceptImmigrants(rd.apply(migratingkey.apply(i))._2,acceptImmigrants)
    }
  }
  var m=population(2)._2.getKey
  m.toInt%numPartitions//???没运行
}*/


  override def equals(other: Any): Boolean = other match {
    case iteblog: IteblogPartitioner =>
      iteblog.numPartitions == numPartitions
    case _ =>
      false
  }

  override def hashCode: Int = numPartitions
}
/*
object Partitioner {
  /**
    * Choose a partitioner to use for a cogroup-like operation between a number of RDDs.
    *
    * If any of the RDDs already has a partitioner, choose that one.
    *
    * Otherwise, we use a default HashPartitioner. For the number of partitions, if
    * spark.default.parallelism is set, then we'll use the value from SparkContext
    * defaultParallelism, otherwise we'll use the max number of upstream partitions.
    *
    * Unless spark.default.parallelism is set, the number of partitions will be the
    * same as the number of partitions in the largest upstream RDD, as this should
    * be least likely to cause out-of-memory errors.
    *
    * We use two method parameters (rdd, others) to enforce callers passing at least 1 RDD.
    */
  def defaultPartitioner(rdd: RDD[_], others: RDD[_]*): Partitioner = {
    val bySize = (Seq(rdd) ++ others).sortBy(_.partitions.size).reverse
    for (r <- bySize if r.partitioner.isDefined) {
      return r.partitioner.get
    }
    if (rdd.context.getConf.contains("spark.default.parallelism")) {
      new HashPartitioner(rdd.context.defaultParallelism)
    } else {
      new HashPartitioner(bySize.head.partitions.size)
    }
  }
}
*/


