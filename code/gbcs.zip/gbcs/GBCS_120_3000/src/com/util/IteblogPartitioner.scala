package com.util
import org.apache.spark.Partitioner
/**
 * Created by hadoop on 16-11-9.
 */
/*
def numPartitions: Int：这个方法需要返回你想要创建分区的个数；
def getPartition(key: Any): Int：这个函数需要对输入的key做计算，
    然后返回该key的分区ID，范围一定是0到numPartitions-1；
equals()：这个是Java标准的判断相等的函数，
    之所以要求用户实现这个函数是因为Spark内部会比较两个RDD的分区是否一样。
 */
/*
假如我们想把来自同一个域名的URL放到一台节点上，
比如:http://www.iteblog.com和http://www.iteblog.com/archives/1368，
如果你使用HashPartitioner，这两个URL的Hash值可能不一样，这就使得这两个URL被放到不同的节点上。
所以这种情况下我们就需要自定义我们的分区策略，可以如下实现：
 */
class IteblogPartitioner(numParts: Int) extends Partitioner{
    override def numPartitions: Int = numParts
    override def getPartition(key: Any): Int = {
    	    val domain = new java.net.URL(key.toString).getHost()
    	    val code = (domain.hashCode % numPartitions)
     	    if (code < 0) {
       	      code + numPartitions
       	  } else {
       	      code
         	}
    }

  	override def equals(other: Any): Boolean = other match {
   	    case iteblog: IteblogPartitioner =>
       	      iteblog.numPartitions == numPartitions
   	    case _ =>
       	      false
      	  }

  	override def hashCode: Int = numPartitions
}
