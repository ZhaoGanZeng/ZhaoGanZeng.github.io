package com.txj.dg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HelloWorld {
    /**
     *得到要用来进行演示的数据  
     * @return
     */
    public static List<Integer> initData(){
        List<Integer> datas = new ArrayList<Integer>();
        Integer data = null;
        for(int i=11;i<=20;i++){
            data = new Integer(i);
            datas.add(data);
        }
        return datas;
    }

    public static void main(String[] args) {
        int[] indexArr = new int[]{1,9,2,5};
        //定义要删除list中集合的下标组合，一般在真正项目中，这个数组都是有程序执行得到，一般都是排序正常的
        //这里为了演示如何对数组进行排序，所以打乱了顺序

        //调用Arrays这个类的静态方法sort对数组进行排序，排序结果为正序
        Arrays.sort(indexArr);

        //打印出来看看
        for(Integer index : indexArr){
            System.out.println(index);
        }

        List<Integer> datas = initData(); //得到测试数据

        //因为要删除list里面的多个的值，所以会涉及到一个问题，就是当你删除掉下标为1的元素十，
        //原来下标为2的元素会自动改变自己的下标为0，后面的元素依次把自己的下标值减一
        //鉴于这种情况，我们想循环删除list中的多个元素的话，就必须从后往前删，这样保障了你删除了一个元素之后，
        //list中元素的下标移动不会影响到那些需要删除，但是还未删除到的以元素
        System.out.println("删除前:  "+datas);

        //删除多个指定下标的数据
        for(int i=indexArr.length-1;i>=0;i--){ //倒序
            if(i<=datas.size()){
                System.out.println("删除了第  "+(indexArr[i]+1)+" 个元素");
                datas.remove(indexArr[i]);
            }
        }

        System.out.println("删除后:  "+datas);
    }
}