package com.txj.Commons;
import java.math.*;

public class CFunction {
	// public double params[];//参数个数
	public double parmin;// 参数下线
	public double parmax;// 参数上线
	public boolean flag;// 求解最大值还是最小值
	//实例化对象为数组


	public CFunction(double parmin, double parmax, boolean flag) {
		this.parmin = parmin;//-2
		this.parmax = parmax;//3
		this.flag = flag;
	}

	public double Compute(int i, double pars[]) {
		return Function.Func(i, pars);
	}

}