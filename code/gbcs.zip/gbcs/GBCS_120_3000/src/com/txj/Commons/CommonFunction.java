package com.txj.Commons;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;

public class CommonFunction {


	
	//适应度函数
	public double Compute(int i, double parsArg[]) {		
		return Function.Func(i, parsArg);
		//return Function.Func1(parsArg);
	}
	
	//适应度函数
	//将LongWritable类型转化为double类型
	public double Compute(int j, DoubleWritable parsArg[]) {
		double pars[] = new double[parsArg.length];
		for (int i = 0; i < parsArg.length; i++) {
			pars[i]=parsArg[i].get();
		}
		return Function.Func(j,pars);
	}

}
